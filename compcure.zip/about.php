<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us | Complaint Management System</title>
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@400;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --accent: #f72585;
            --light: #f8f9fa;
            --dark: #212529;
            --success: #4cc9f0;
            --warning: #f8961e;
            --info: #4895ef;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            color: var(--dark);
            line-height: 1.6;
            background-image: url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(248, 249, 250, 0.9);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px 0;
        }

        /* Header Styles */
        .hero-section {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 100px 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            margin-bottom: 40px;
            border-radius: 0 0 20px 20px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        .hero-section::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
            opacity: 0.3;
        }

        .hero-section h1 {
            font-family: 'Montserrat', sans-serif;
            font-size: 3rem;
            font-weight: 700;
            margin-bottom: 20px;
            text-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .hero-section p {
            font-size: 1.2rem;
            margin-bottom: 30px;
            opacity: 0.9;
        }

        /* Button Styles */
        .btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: var(--accent);
            color: white;
            border: none;
            border-radius: 50px;
            font-weight: 600;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(247, 37, 133, 0.3);
        }

        .btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(247, 37, 133, 0.4);
            background-color: #f50076;
        }

        .btn-outline {
            background: transparent;
            border: 2px solid white;
            margin-left: 15px;
        }

        .btn-outline:hover {
            background: white;
            color: var(--primary);
        }

        /* Section Titles */
        .section-title {
            text-align: center;
            margin-bottom: 50px;
        }

        .section-title h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.5rem;
            color: var(--primary);
            margin-bottom: 15px;
        }

        .section-title p {
            color: #666;
            max-width: 700px;
            margin: 0 auto;
        }

        /* About Content */
        .about-content {
            display: flex;
            gap: 40px;
            margin-bottom: 60px;
            align-items: center;
        }

        .about-text {
            flex: 1;
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .about-image {
            flex: 1;
            border-radius: 15px;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .about-image:hover {
            transform: scale(1.02);
        }

        .about-image img {
            width: 100%;
            height: auto;
            display: block;
        }

        /* Mission/Vision */
        .mission-vision {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        .mission-card, .vision-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease;
        }

        .mission-card:hover, .vision-card:hover {
            transform: translateY(-5px);
        }

        .mission-card::before, .vision-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
        }

        .mission-icon, .vision-icon {
            font-size: 3rem;
            color: var(--primary);
            margin-bottom: 20px;
            transition: transform 0.3s ease;
        }

        .mission-card:hover .mission-icon,
        .vision-card:hover .vision-icon {
            transform: scale(1.1);
        }

        /* Team Section */
        .team-section {
            margin-bottom: 60px;
        }

        .team-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
        }

        .team-card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 30px;
            text-align: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            transition: all 0.3s ease;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .team-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.1);
        }

        .team-image {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 20px;
            border: 5px solid rgba(67, 97, 238, 0.1);
            transition: transform 0.3s ease, border-color 0.3s ease;
        }

        .team-card:hover .team-image {
            transform: scale(1.05);
            border-color: rgba(67, 97, 238, 0.3);
        }

        .team-card h3 {
            font-size: 1.3rem;
            margin-bottom: 5px;
        }

        .team-card p.position {
            color: var(--primary);
            font-weight: 500;
            margin-bottom: 15px;
        }

        .team-card p.bio {
            color: #666;
            margin-bottom: 20px;
            font-size: 0.95rem;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 15px;
        }

        .social-links a {
            width: 35px;
            height: 35px;
            background: rgba(67, 97, 238, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-3px);
        }

        /* Journey Section */
        .journey-section {
            margin-bottom: 60px;
        }

        .timeline {
            position: relative;
            max-width: 1000px;
            margin: 0 auto;
            padding: 40px 0;
        }

        .timeline::before {
            content: '';
            position: absolute;
            top: 0;
            left: 50%;
            transform: translateX(-50%);
            width: 3px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary), var(--accent));
        }

        .timeline-item {
            position: relative;
            width: 50%;
            padding: 20px 40px;
            box-sizing: border-box;
        }

        .timeline-item:nth-child(odd) {
            left: 0;
            text-align: right;
            padding-right: 80px;
        }

        .timeline-item:nth-child(even) {
            left: 50%;
            padding-left: 80px;
        }

        .timeline-content {
            background: rgba(255, 255, 255, 0.95);
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.05);
            position: relative;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
            transition: transform 0.3s ease;
        }

        .timeline-item:hover .timeline-content {
            transform: scale(1.02);
        }

        .timeline-content::before {
            content: '';
            position: absolute;
            width: 25px;
            height: 25px;
            background: var(--primary);
            border-radius: 50%;
            top: 30px;
        }

        .timeline-item:nth-child(odd) .timeline-content::before {
            right: -62px;
        }

        .timeline-item:nth-child(even) .timeline-content::before {
            left: -62px;
        }

        .timeline-date {
            color: var(--primary);
            font-weight: 600;
            margin-bottom: 10px;
        }

        .timeline-content h3 {
            font-size: 1.3rem;
            margin-bottom: 10px;
            display: flex;
            align-items: center;
        }

        .timeline-item:nth-child(odd) h3 {
            justify-content: flex-end;
        }

        .timeline-item:nth-child(even) h3 {
            justify-content: flex-start;
        }

        .timeline-icon {
            margin-left: 10px;
            font-size: 1.2rem;
            transition: transform 0.3s ease;
        }

        .timeline-item:hover .timeline-icon {
            transform: rotate(15deg);
        }

        .timeline-item:nth-child(even) .timeline-icon {
            margin-left: 0;
            margin-right: 10px;
        }

        /* CTA Section */
        .cta-section {
            margin-bottom: 60px;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {
            .about-content {
                flex-direction: column;
            }
            
            .about-text {
                order: 2;
            }
            
            .about-image {
                order: 1;
                margin-bottom: 30px;
            }
            
            .timeline::before {
                left: 30px;
            }
            
            .timeline-item {
                width: 100%;
                padding-left: 80px;
                padding-right: 20px;
            }
            
            .timeline-item:nth-child(even) {
                left: 0;
            }
            
            .timeline-item:nth-child(odd) .timeline-content::before,
            .timeline-item:nth-child(even) .timeline-content::before {
                left: 20px;
                right: auto;
            }
            
            .timeline-item:nth-child(odd) {
                text-align: left;
            }
            
            .timeline-item:nth-child(odd) h3 {
                justify-content: flex-start;
            }
            
            .timeline-item:nth-child(even) .timeline-icon {
                order: -1;
                margin-right: 10px;
                margin-left: 0;
            }
        }

        @media (max-width: 480px) {
            .hero-section h1 {
                font-size: 2rem;
            }
            
            .section-title h2 {
                font-size: 1.8rem;
            }
            
            .btn-group {
                display: flex;
                flex-direction: column;
                gap: 15px;
            }
            
            .btn-outline {
                margin-left: 0;
            }
            
            .mission-vision {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <?php include 'header.php'; ?>

    <!-- Hero Section -->
    <section class="hero-section">
        <div class="hero-content">
            <h1>About Our Complaint Management System</h1>
            <p>Learn about our mission, vision, and the dedicated team behind our powerful complaint management platform</p>
        </div>
    </section>

    <!-- Main Content -->
    <div class="container">
        <!-- About Section -->
        <section>
            <div class="about-content">
                <div class="about-text">
                    <h2>Who We Are</h2>
                    <p>We are a team of passionate professionals dedicated to transforming how organizations handle customer complaints. Our complaint management system was born out of a need for more efficient, transparent, and customer-centric resolution processes.</p>
                    <p>With years of experience in customer service and technology development, we've built a platform that not only streamlines complaint resolution but also provides valuable insights to prevent future issues.</p>
                    <p>Our system is trusted by businesses across various industries to maintain high customer satisfaction and operational efficiency.</p>
                </div>
                <div class="about-image">
                    <img src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80" alt="Team working together">
                </div>
            </div>
        </section>

        <!-- Mission/Vision -->
        <section>
            <div class="mission-vision">
                <div class="mission-card">
                    <div class="mission-icon">
                        <i class="fas fa-bullseye"></i>
                    </div>
                    <h3>Our Mission</h3>
                    <p>To empower organizations with innovative tools that transform customer complaints into opportunities for improvement, fostering trust and loyalty through transparent and efficient resolution processes.</p>
                </div>
                <div class="vision-card">
                    <div class="vision-icon">
                        <i class="fas fa-eye"></i>
                    </div>
                    <h3>Our Vision</h3>
                    <p>To become the global standard in complaint management solutions, recognized for our commitment to customer satisfaction, data-driven insights, and continuous innovation in resolution technologies.</p>
                </div>
            </div>
        </section>

        <!-- Team Section -->
        <section id="team" class="team-section">
            <div class="section-title">
                <h2>Meet Our Team</h2>
                <p>The dedicated professionals behind our complaint management system</p>
            </div>
            
            <div class="team-grid">
                <div class="team-card">
                    <img src="/final/assets/shrinu.png" alt="Shri Walikar" class="team-image">
                    <h3>Walikar Shrinivas</h3>
                    <p class="position">Team Lead & Backend Developer</p>
                    <p class="bio">Manages the complaint data architecture and ensures system security and scalability.</p>
                    <div class="social-links">
                        <a href="https://www.instagram.com/__shrinivas__24/?utm_source=ig_web_button_share_sheet"><i class="fab fa-instagram"></i></a>
                        <a href="https://github.com/shrinivas004"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                
                <div class="team-card">
                    <img src="/final/assets/om.jpg" alt="Sonkade Onkar" class="team-image">
                    <h3>Sonkade Onkar</h3>
                    <p class="position">Frontend Developer</p>
                    <p class="bio">Designs intuitive user interfaces that make complaint submission and tracking effortless.</p>
                    <div class="social-links">
                        <a href="https://www.instagram.com/accounts/edit/"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                
                <div class="team-card">
                    <img src="/final/assets/sumit.png" alt="Sumit Patil" class="team-image">
                    <h3>Patil Sumit</h3>
                    <p class="position">Documentation Specialist</p>
                    <p class="bio">Ensures all system processes are well-documented for both users and administrators.</p>
                    <div class="social-links">
                        <a href="https://www.instagram.com/sumit_patil_0078/"><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
                
                <div class="team-card">
                    <img src="/final/assets/abhi.png" alt="Abhishek Arjun" class="team-image">
                    <h3>Arjun Abhishek</h3>
                    <p class="position">Quality Assurance</p>
                    <p class="bio">Tests all system features to ensure reliability and optimal user experience.</p>
                    <div class="social-links">
                        <a href="https://www.instagram.com/_abhishek_8888_?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                        <a href="#"><i class="fab fa-github"></i></a>
                        <a href="#"><i class="fas fa-envelope"></i></a>
                    </div>
                </div>
            </div>
        </section>

        <!-- Journey Section -->
        <section class="journey-section">
            <div class="section-title">
                <h2>Our Development Journey</h2>
                <p>How we built our comprehensive complaint management system</p>
            </div>
            
            <div class="timeline">
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-date">Phase 1</div>
                        <h3>Research & Planning <i class="fas fa-search timeline-icon"></i></h3>
                        <p>Conducted market research and defined system requirements to address pain points in complaint management.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-date">Phase 2</div>
                        <h3><i class="fas fa-pencil-ruler timeline-icon"></i> Design & Prototyping</h3>
                        <p>Created wireframes and prototypes focusing on user experience and efficient workflow design.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-date">Phase 3</div>
                        <h3>Core Development <i class="fas fa-code timeline-icon"></i></h3>
                        <p>Built the foundational architecture with secure database design and robust API integrations.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-date">Phase 4</div>
                        <h3><i class="fas fa-bug timeline-icon"></i> Testing & Refinement</h3>
                        <p>Conducted rigorous testing cycles to ensure reliability, security, and performance.</p>
                    </div>
                </div>
                
                <div class="timeline-item">
                    <div class="timeline-content">
                        <div class="timeline-date">Phase 5</div>
                        <h3>Launch & Growth <i class="fas fa-rocket timeline-icon"></i></h3>
                        <p>Successfully deployed the system and continue to enhance features based on user feedback.</p>
                    </div>
                </div>
            </div>
        </section>

        <!-- CTA Section -->
        <section class="cta-section">
            <div class="section-title">
                <h2>Ready to Transform Your Complaint Management?</h2>
                <p>Join organizations worldwide improving customer satisfaction with our system</p>
            </div>
            <div style="text-align: center;">
                <a href="demo.php" class="btn">Request Demo</a>
                <a href="contact.html" class="btn btn-outline">Contact Sales</a>
            </div>
        </section>
    </div>

    <?php include 'footer.php'; ?>

    <script>
        // Add subtle animations when elements come into view
        document.addEventListener('DOMContentLoaded', function() {
            const animateOnScroll = function() {
                const elements = document.querySelectorAll('.about-text, .mission-card, .vision-card, .team-card, .timeline-content');
                
                elements.forEach(element => {
                    const elementPosition = element.getBoundingClientRect().top;
                    const screenPosition = window.innerHeight / 1.2;
                    
                    if(elementPosition < screenPosition) {
                        element.style.opacity = '1';
                        element.style.transform = 'translateY(0)';
                    }
                });
            };
            
            // Set initial state for animated elements
            const animatedElements = document.querySelectorAll('.about-text, .mission-card, .vision-card, .team-card, .timeline-content');
            animatedElements.forEach(element => {
                element.style.opacity = '0';
                element.style.transform = 'translateY(20px)';
                element.style.transition = 'all 0.5s ease';
            });
            
            // Run once on load
            animateOnScroll();
            
            // Run on scroll
            window.addEventListener('scroll', animateOnScroll);
        });
    </script>
</body>
</html>