<?php
$successMessage = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "complaint_system";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $message = $_POST['message'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO contacts (name, email, message) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $name, $email, $message);

    // Execute the statement
    if ($stmt->execute()) {
        $successMessage = "Your message has been sent successfully!";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close connection
    $stmt->close();
    $conn->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #4361ee;
            --dark-blue: #3f37c9;
            --light-blue: #4895ef;
            --accent: #f72585;
            --white: #ffffff;
            --light-gray: #f8f9fa;
            --medium-gray:rgb(2, 8, 15);
            --dark-gray: #64748b;
            --text-color: #212529;
            --success: #4cc9f0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: var(--light-gray);
            color: var(--text-color);
            line-height: 1.6;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            margin: 0;
            padding: 0;
            background-image: url('https://images.unsplash.com/photo-1552664730-d307ca884978?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(255, 255, 255, 0.9);
        }

        .container {
            width: 90%;
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 0;
            flex: 1;
        }

        /* Header Section */
        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: var(--white);
            padding: 100px 0;
            text-align: center;
            margin-bottom: 40px;
            position: relative;
            overflow: hidden;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            border-radius: 0 0 20px 20px;
        }

        .header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
            opacity: 0.3;
        }

        .header-content {
            position: relative;
            z-index: 1;
            max-width: 800px;
            margin: 0 auto;
            animation: fadeInUp 0.8s ease;
        }

        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .header h1 {
            font-size: 2.8rem;
            font-weight: 700;
            margin-bottom: 16px;
            letter-spacing: -0.5px;
        }

        .header p {
            font-size: 1.2rem;
            opacity: 0.9;
            max-width: 700px;
            margin: 0 auto;
        }

        /* Content Layout */
        .content-wrapper {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
            gap: 30px;
            margin-bottom: 60px;
        }

        /* Cards */
        .card {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
            transition: all 0.4s ease;
            height: 100%;
            position: relative;
            overflow: hidden;
            backdrop-filter: blur(5px);
            border: 1px solid rgba(255, 255, 255, 0.2);
        }

        .card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.15);
        }

        .card h2 {
            color: var(--primary-blue);
            font-size: 1.8rem;
            margin-bottom: 30px;
            position: relative;
            padding-bottom: 15px;
        }

        .card h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, var(--primary-blue), var(--accent));
            border-radius: 2px;
        }

        /* Contact Information */
        .contact-details {
            display: grid;
            gap: 25px;
        }

        .contact-item {
            display: flex;
            align-items: flex-start;
            gap: 20px;
            transition: all 0.3s ease;
        }

        .contact-item:hover {
            transform: translateX(5px);
        }

        .contact-icon {
            width: 50px;
            height: 50px;
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            color: var(--white);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            flex-shrink: 0;
            transition: all 0.3s ease;
        }

        .contact-item:hover .contact-icon {
            background: linear-gradient(135deg, var(--accent), var(--primary-blue));
            transform: scale(1.1);
        }

        .contact-text h3 {
            margin: 0 0 8px 0;
            color: var(--text-color);
            font-size: 1.1rem;
            font-weight: 600;
        }

        .contact-text p, .contact-text a {
            margin: 0;
            color: var(--dark-gray);
            font-size: 0.95rem;
            line-height: 1.6;
        }

        .contact-text a {
            color: var(--primary-blue);
            text-decoration: none;
            transition: all 0.3s ease;
            position: relative;
        }

        .contact-text a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--accent);
            transition: width 0.3s ease;
        }

        .contact-text a:hover {
            color: var(--accent);
        }

        .contact-text a:hover::after {
            width: 100%;
        }

        /* Form Styles */
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
        }

        .form-control {
            width: 100%;
            padding: 14px 20px;
            border: 1px solid var(--medium-gray);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: rgba(248, 249, 250, 0.8);
        }

        .form-control:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
            outline: none;
            background-color: var(--white);
        }

        textarea.form-control {
            min-height: 150px;
            resize: vertical;
        }

        .submit-btn {
            background: linear-gradient(135deg, var(--primary-blue), var(--accent));
            color: var(--white);
            border: none;
            padding: 14px 30px;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
            position: relative;
            overflow: hidden;
        }

        .submit-btn:hover {
            background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4);
        }

        .submit-btn:active {
            transform: translateY(0);
        }

        .submit-btn.loading {
            pointer-events: none;
        }

        .submit-btn.loading::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-blue), var(--accent));
            animation: buttonLoading 1.5s linear infinite;
        }

        @keyframes buttonLoading {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        /* Success Message */
        .success-message {
            background: var(--success);
            color: var(--white);
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            display: none;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.5s ease;
        }

        .success-message.show {
            display: flex;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .success-message i {
            font-size: 1.3rem;
        }

        /* Footer */
        .footer {
            background: rgba(33, 37, 41, 0.9);
            color: var(--white);
            padding: 40px 0;
            text-align: center;
            border-radius: 12px 12px 0 0;
            margin-top: auto;
            backdrop-filter: blur(5px);
        }

        .footer p {
            margin: 8px 0;
        }

        .social-links {
            display: flex;
            justify-content: center;
            gap: 16px;
            margin: 20px 0;
        }

        .social-links a {
            color: var(--white);
            background: rgba(255, 255, 255, 0.1);
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
        }

        .social-links a:hover {
            background: var(--primary-blue);
            transform: translateY(-3px);
        }

        /* Floating Image */
        .floating-image {
            position: absolute;
            right: 40px;
            bottom: 40px;
            width: 200px;
            animation: float 6s ease-in-out infinite;
            opacity: 0.9;
            display: none;
        }

        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-20px); }
            100% { transform: translateY(0px); }
        }

        /* Responsive */
        @media (min-width: 992px) {
            .floating-image {
                display: block;
            }
            
            .contact-form-container .card {
                padding-right: 60px;
            }
        }

        @media (max-width: 768px) {
            .header {
                padding: 80px 0;
            }
            
            .header h1 {
                font-size: 2.2rem;
            }
            
            .header p {
                font-size: 1.1rem;
            }
            
            .content-wrapper {
                grid-template-columns: 1fr;
            }
            
            .card {
                padding: 30px;
            }
        }

        @media (max-width: 480px) {
            .header {
                padding: 60px 20px;
            }
            
            .header h1 {
                font-size: 1.8rem;
            }
            
            .card h2 {
                font-size: 1.5rem;
            }
            
            .contact-item {
                flex-direction: column;
                gap: 12px;
            }
            
            .contact-icon {
                width: 44px;
                height: 44px;
                font-size: 1rem;
            }
            
            .submit-btn {
                width: 100%;
                justify-content: center;
            }
        }

        /* Input animations */
        .form-group input, .form-group textarea {
            transition: all 0.3s ease;
        }

        .form-group input:focus, .form-group textarea:focus {
            transform: scale(1.01);
        }

        /* Sticky form on scroll */
        @media (min-width: 992px) {
            .contact-form-container {
                position: sticky;
                top: 120px;
            }
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?>

<div class="header">
    <div class="header-content">
        <h1>Contact Our Team</h1>
        <p>Have questions or need support? Reach out to us through any of these channels and we'll get back to you promptly.</p>
    </div>
</div>

<div class="container">
    <div class="content-wrapper">
        <div class="contact-info">
            <div class="card">
                <h2>Our Contact Details</h2>
                <div class="contact-details">
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-text">
                            <h3>Office Location</h3>
                            <p>413224-Solapur, India</p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h3>Email Address</h3>
                            <p><a href="mailto:support@complaintsystem.com">support@complaintsystem.com</a></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-phone-alt"></i>
                        </div>
                        <div class="contact-text">
                            <h3>Phone Number</h3>
                            <p><a href="tel:+917972588319">+91 7972588319</a></p>
                        </div>
                    </div>
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="contact-text">
                            <h3>Working Hours</h3>
                            <p>Monday - Friday: 9:00 AM - 5:00 PM<br>Saturday: 10:00 AM - 3:00 PM</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="contact-form-container">
            <div class="card">
                <h2>Send Us a Message</h2>
                
                <div class="success-message" id="successMessage">
                    <i class="fas fa-check-circle"></i>
                    <span id="successText"></span>
                </div>
                
                <form action="contact.php" method="POST" id="contactForm">
                    <div class="form-group">
                        <label for="name">Full Name</label>
                        <input type="text" id="name" name="name" class="form-control" placeholder="Enter your full name" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email Address</label>
                        <input type="email" id="email" name="email" class="form-control" placeholder="Enter your email address" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="message">Your Message</label>
                        <textarea id="message" name="message" class="form-control" placeholder="Type your message here..." required></textarea>
                    </div>
                    
                    <button type="submit" class="submit-btn" id="submitBtn">
                        <i class="fas fa-paper-plane"></i>
                        <span id="buttonText">Send Message</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Animation for form elements
        const formGroups = document.querySelectorAll('.form-group');
        
        formGroups.forEach((group, index) => {
            group.style.opacity = '0';
            group.style.transform = 'translateY(20px)';
            group.style.transition = 'all 0.5s ease ' + (index * 0.1) + 's';
            
            setTimeout(() => {
                group.style.opacity = '1';
                group.style.transform = 'translateY(0)';
            }, 100);
        });
        
        // Hover effect for contact items
        const contactItems = document.querySelectorAll('.contact-item');
        contactItems.forEach(item => {
            item.addEventListener('mouseenter', () => {
                item.querySelector('.contact-icon').style.transform = 'scale(1.1)';
            });
            item.addEventListener('mouseleave', () => {
                item.querySelector('.contact-icon').style.transform = 'scale(1)';
            });
        });

        // Form submission handling
        const contactForm = document.getElementById('contactForm');
        const submitBtn = document.getElementById('submitBtn');
        const buttonText = document.getElementById('buttonText');
        const successMessage = document.getElementById('successMessage');
        const successText = document.getElementById('successText');
        
        if (contactForm) {
            contactForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                submitBtn.classList.add('loading');
                buttonText.textContent = 'Sending...';
                
                // Simulate loading for 3 seconds
                setTimeout(() => {
                    // Remove loading state
                    submitBtn.classList.remove('loading');
                    buttonText.textContent = 'Send Message';
                    
                    // Show success message
                    successText.textContent = "<?php echo $successMessage ? $successMessage : 'Your message has been sent successfully!' ?>";
                    successMessage.classList.add('show');
                    
                    // Hide the success message after 5 seconds
                    setTimeout(() => {
                        successMessage.classList.remove('show');
                    }, 5000);
                    
                    // Reset form
                    contactForm.reset();
                    
                    // Actually submit the form (remove this if you want to handle with AJAX)
                    this.submit();
                }, 3000);
            });
        }

        // Hide PHP success message after 5 seconds if it exists
        <?php if (!empty($successMessage)): ?>
            successText.textContent = "<?php echo $successMessage ?>";
            successMessage.classList.add('show');
            
            setTimeout(() => {
                successMessage.classList.remove('show');
            }, 5000);
        <?php endif; ?>
    });
</script>
</body>
</html>