<?php
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$database = "complaint_system";

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM feedback ORDER BY submitted_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Feedback | CompCure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700;800&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-color: #6c63ff;
            --secondary-color: #4d44db;
            --accent-color: #ff6584;
            --light-color: #f8f9fa;
            --dark-color: #2b2d42;
            --text-color: #4a4a4a;
            --success-color: #4cc9f0;
            --error-color: #ef233c;
            --border-radius: 10px;
            --box-shadow: 0 10px 30px rgba(108, 99, 255, 0.2);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f5f7ff;
            color: var(--text-color);
            line-height: 1.6;
        }

        .container {
            max-width: 1400px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .page-header {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }

        .page-header h2 {
            font-family: 'Montserrat', sans-serif;
            font-size: 2.5rem;
            font-weight: 700;
            color: var(--dark-color);
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .page-header p {
            color: var(--text-color);
            opacity: 0.8;
            max-width: 700px;
            margin: 0 auto;
        }

        .feedback-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
            gap: 30px;
        }

        .feedback-card {
            background: white;
            border-radius: var(--border-radius);
            padding: 30px;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            border-left: 4px solid var(--primary-color);
            display: flex;
            flex-direction: column;
            height: 100%;
            position: relative;
            overflow: hidden;
        }

        .feedback-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(108, 99, 255, 0.25);
        }

        .feedback-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 4px;
            background: linear-gradient(90deg, var(--primary-color), var(--accent-color));
        }

        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: flex-start;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px dashed #e0e0e0;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .user-avatar {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 1.2rem;
        }

        .user-details {
            flex: 1;
        }

        .user-name {
            font-weight: 600;
            color: var(--dark-color);
            font-size: 1.1rem;
            margin-bottom: 3px;
        }

        .user-email {
            font-size: 0.85rem;
            color: #78909c;
            word-break: break-all;
        }

        .rating {
            display: flex;
            align-items: center;
            gap: 5px;
            background: rgba(255, 193, 7, 0.1);
            padding: 5px 10px;
            border-radius: 20px;
            color: #ffc107;
            font-weight: 600;
            font-size: 0.9rem;
        }

        .card-body {
            flex-grow: 1;
            color: var(--text-color);
            line-height: 1.7;
            margin-bottom: 20px;
            padding-right: 10px;
            position: relative;
        }

        .feedback-text {
            max-height: 120px;
            overflow-y: auto;
            padding-right: 10px;
        }

        .feedback-text::-webkit-scrollbar {
            width: 5px;
        }

        .feedback-text::-webkit-scrollbar-track {
            background: #f1f1f1;
        }

        .feedback-text::-webkit-scrollbar-thumb {
            background: var(--primary-color);
            border-radius: 5px;
        }

        .card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            font-size: 0.85rem;
            color: #90a4ae;
            padding-top: 15px;
            border-top: 1px dashed #e0e0e0;
        }

        .feedback-date {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .feedback-actions {
            display: flex;
            gap: 10px;
        }

        .action-btn {
            background: none;
            border: none;
            color: #78909c;
            cursor: pointer;
            transition: var(--transition);
            font-size: 0.9rem;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .action-btn:hover {
            color: var(--primary-color);
        }

        .no-feedback {
            text-align: center;
            padding: 60px 20px;
            grid-column: 1 / -1;
        }

        .no-feedback i {
            font-size: 3rem;
            color: #cfd8dc;
            margin-bottom: 20px;
        }

        .no-feedback h3 {
            font-size: 1.5rem;
            color: #78909c;
            margin-bottom: 10px;
        }

        .no-feedback p {
            color: #90a4ae;
            max-width: 500px;
            margin: 0 auto;
        }

        @media (max-width: 1024px) {
            .feedback-grid {
                grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            }
        }

        @media (max-width: 768px) {
            .page-header h2 {
                font-size: 2rem;
            }
            
            .feedback-card {
                padding: 25px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 30px 15px;
            }
            
            .page-header h2 {
                font-size: 1.8rem;
                flex-direction: column;
                gap: 10px;
            }
            
            .feedback-grid {
                grid-template-columns: 1fr;
            }
            
            .user-info {
                flex-direction: column;
                align-items: flex-start;
                gap: 10px;
            }
        }
    </style>
</head>
<body>
<?php include 'header.php'; ?>

<div class="container">
    <div class="page-header">
        <h2><i class="fas fa-comment-alt"></i> Customer Feedback</h2>
        <p>Read what our users have to say about their experience with CompCure</p>
    </div>

    <div class="feedback-grid">
        <?php if ($result->num_rows > 0): ?>
            <?php while ($row = $result->fetch_assoc()): ?>
                <div class="feedback-card">
                    <div class="card-header">
                        <div class="user-info">
                            <div class="user-avatar">
                                <?= strtoupper(substr($row["user_name"], 0, 1)) ?>
                            </div>
                            <div class="user-details">
                                <div class="user-name"><?= htmlspecialchars($row["user_name"]) ?></div>
                                <div class="user-email"><?= htmlspecialchars($row["user_email"] ?? 'N/A') ?></div>
                            </div>
                        </div>
                        <div class="rating">
                            <i class="fas fa-star"></i>
                            <span><?= $row["rating"] ?></span>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="feedback-text">
                            <?= nl2br(htmlspecialchars($row["feedback"])) ?>
                        </div>
                    </div>
                    <div class="card-footer">
                        <div class="feedback-date">
                            <i class="far fa-clock"></i>
                            <span><?= date("M d, Y h:i A", strtotime($row["submitted_at"])) ?></span>
                        </div>
                        <div class="feedback-actions">
                            <button class="action-btn">
                                <i class="far fa-thumbs-up"></i>
                                <span>Helpful</span>
                            </button>
                            <button class="action-btn">
                                <i class="fas fa-reply"></i>
                                <span>Reply</span>
                            </button>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="no-feedback">
                <i class="far fa-comment-dots"></i>
                <h3>No Feedback Yet</h3>
                <p>We haven't received any feedback yet. Check back later or be the first to share your experience.</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Animation for cards
        const cards = document.querySelectorAll('.feedback-card');
        cards.forEach((card, index) => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = `all 0.5s ease ${index * 0.1}s`;
            
            setTimeout(() => {
                card.style.opacity = '1';
                card.style.transform = 'translateY(0)';
            }, 100);
        });
    });
</script>
</body>
</html>

<?php $conn->close(); ?>