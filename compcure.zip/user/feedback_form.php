<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Submit Feedback | Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --primary-light: #e6ebfd;
        --secondary: #3f37c9;
        --success: #4cc9a0;
        --warning: #f8961e;
        --danger: #f94144;
        --light: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #6c757d;
        --dark: #212529;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        --border-radius: 0.5rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background-color: var(--light-gray);
        color: var(--dark);
        line-height: 1.6;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    /* Modern Sidebar */
    .sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 100;
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--medium-gray);
        transition: transform 0.3s ease;
    }

    .sidebar-header {
        margin-bottom: 2.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid var(--medium-gray);
    }

    .sidebar-header h2 {
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-header h2 i {
        font-size: 1.75rem;
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--dark-gray);
        padding: 0.875rem 1.25rem;
        border-radius: var(--border-radius);
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
    }

    .nav-item:hover {
        background-color: var(--primary-light);
        color: var(--primary);
        transform: translateX(5px);
    }

    .nav-item.active {
        background-color: var(--primary-light);
        color: var(--primary);
        font-weight: 600;
    }

    .nav-item i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        margin-top: auto;
        padding-top: 1.5rem;
        border-top: 1px solid var(--medium-gray);
    }

    /* Main Content */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2.5rem;
        transition: margin-left 0.3s ease;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    /* Feedback Form Container */
    .form-card {
        background: var(--light);
        padding: 2.5rem;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--medium-gray);
        width: 100%;
        max-width: 500px;
    }

    .form-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .form-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
    }

    .form-header p {
        color: var(--dark-gray);
        margin-top: 0.5rem;
    }

    .form-group {
        margin-bottom: 1.5rem;
    }

    label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--dark);
        font-weight: 500;
    }

    input, textarea {
        width: 100%;
        padding: 0.875rem 1.25rem;
        border: 1px solid var(--medium-gray);
        border-radius: var(--border-radius);
        background: var(--light);
        transition: var(--transition);
    }

    input:focus, textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
        outline: none;
    }

    /* Rating System */
    .rating-container {
        margin: 1.5rem 0;
        text-align: center;
    }

    .rating-group {
        display: flex;
        justify-content: center;
        gap: 0.5rem;
        margin-top: 1rem;
    }

    .rating-input {
        position: absolute;
        opacity: 0;
    }

    .rating-star {
        font-size: 2rem;
        color: var(--medium-gray);
        cursor: pointer;
        transition: var(--transition);
    }

    .rating-input:checked ~ .rating-star,
    .rating-star:hover,
    .rating-star:hover ~ .rating-star {
        color: var(--warning);
    }

    /* Submit Button with Loading Animation */
    .submit-btn {
        background: var(--primary);
        color: var(--light);
        padding: 1rem 2rem;
        border: none;
        border-radius: var(--border-radius);
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: var(--transition);
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        position: relative;
        overflow: hidden;
    }

    .submit-btn:hover {
        background: var(--primary-dark);
        box-shadow: var(--shadow-md);
    }

    .submit-btn .button-text {
        transition: opacity 0.3s ease;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .submit-btn .loading-spinner {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 24px;
        height: 24px;
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: #fff;
        animation: spin 1s linear infinite;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .submit-btn.loading .button-text {
        opacity: 0;
    }

    .submit-btn.loading .loading-spinner {
        opacity: 1;
    }

    .submit-btn.loading {
        cursor: not-allowed;
    }

    @keyframes spin {
        0% { transform: translate(-50%, -50%) rotate(0deg); }
        100% { transform: translate(-50%, -50%) rotate(360deg); }
    }

    /* Mobile Toggle Button */
    .mobile-toggle {
        display: none;
        position: fixed;
        top: 1rem;
        left: 1rem;
        z-index: 1000;
        background: var(--primary);
        color: var(--light);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-md);
        justify-content: center;
        align-items: center;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
            padding: 1.5rem;
        }

        .mobile-toggle {
            display: flex;
        }

        .form-card {
            padding: 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .rating-star {
            font-size: 1.75rem;
        }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-gavel"></i>CompCure</h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item">
                <i class="fas fa-edit"></i>
                New Complaint
            </a>
            <a href="complaint_table.php" class="nav-item">
                <i class="fas fa-list"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item active">
                <i class="fas fa-comment-alt"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                Help Center
            </a>
            
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="form-card">
            <div class="form-header">
                <h1><i class="fas fa-comment-dots"></i> Submit Feedback</h1>
                <p>We value your experience with our service</p>
            </div>

            <form id="feedbackForm" action="submit_feedback.php" method="post">
                <div class="form-group">
                    <label for="user_name">Your Name</label>
                    <input type="text" name="user_name" id="user_name" required>
                </div>

                <div class="form-group">
                    <label>Service Rating</label>
                    <div class="rating-container">
                        <div class="rating-group">
                            <input class="rating-input" type="radio" name="rating" id="star5" value="5">
                            <label for="star5" class="rating-star"><i class="fas fa-star"></i></label>
                            
                            <input class="rating-input" type="radio" name="rating" id="star4" value="4">
                            <label for="star4" class="rating-star"><i class="fas fa-star"></i></label>
                            
                            <input class="rating-input" type="radio" name="rating" id="star3" value="3">
                            <label for="star3" class="rating-star"><i class="fas fa-star"></i></label>
                            
                            <input class="rating-input" type="radio" name="rating" id="star2" value="2">
                            <label for="star2" class="rating-star"><i class="fas fa-star"></i></label>
                            
                            <input class="rating-input" type="radio" name="rating" id="star1" value="1">
                            <label for="star1" class="rating-star"><i class="fas fa-star"></i></label>
                        </div>
                    </div>
                </div>

                <div class="form-group">
                    <label for="feedback">Your Feedback</label>
                    <textarea name="feedback" id="feedback" rows="4" required></textarea>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn">
                    <span class="button-text">
                        <i class="fas fa-paper-plane"></i>
                        Submit Feedback
                    </span>
                    <div class="loading-spinner"></div>
                </button>
            </form>
        </div>
    </main>
</div>

<script>
    // Mobile Toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');

    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            sidebar.classList.remove('active');
        }
    });

    // Auto-close sidebar when resizing to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
        }
    });

    // Form submission with loading animation
    const feedbackForm = document.getElementById('feedbackForm');
    const submitBtn = document.getElementById('submitBtn');

    feedbackForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading state
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        // Simulate 3-second processing time
        setTimeout(() => {
            // Submit the form after animation
            this.submit();
        }, 3000);
    });
</script>
</body>
</html>