<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize messages
$success_message = '';
$error_message = '';

// Handle delete request
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $sql = "DELETE FROM complaints WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $delete_id, $user_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Complaint deleted successfully!";
    } else {
        $_SESSION['error_message'] = "Error deleting complaint: " . $conn->error;
    }
    $stmt->close();
    header("Location: complaint_table.php");
    exit();
}

// Handle update request
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_id'])) {
    $update_id = $_POST['update_id'];
    $full_name = $_POST['full_name'];
    $title_of_complaint = $_POST['title_of_complaint'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $details_of_complaint = $_POST['details_of_complaint'];

    $sql = "UPDATE complaints SET full_name = ?, title_of_complaint = ?, state = ?, city = ?, details_of_complaint = ? WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $full_name, $title_of_complaint, $state, $city, $details_of_complaint, $update_id, $user_id);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Complaint updated successfully!";
    } else {
        $_SESSION['error_message'] = "Error updating complaint: " . $conn->error;
    }
    $stmt->close();
    header("Location: complaint_table.php");
    exit();
}

// Check for messages in session
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

// Fetch complaints for the logged-in user excluding closed and completed ones
$sql = "SELECT id, full_name, title_of_complaint, state, city, details_of_complaint, file, reg_date, status 
        FROM complaints 
        WHERE user_id = ? AND status != 'Closed' AND status != 'Completed' 
        ORDER BY reg_date DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Complaints | Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --primary-light: #e6ebfd;
        --secondary: #3f37c9;
        --success: #4cc9a0;
        --success-light: #e6f7f1;
        --warning: #f8961e;
        --warning-light: #fef3e6;
        --danger: #f94144;
        --danger-light: #fee6e7;
        --light: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #6c757d;
        --dark: #212529;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        --border-radius: 0.5rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background-color: var(--light-gray);
        color: var(--dark);
        line-height: 1.6;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    /* Modern Sidebar */
    .sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 100;
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--medium-gray);
        transition: transform 0.3s ease;
    }

    .sidebar-header {
        margin-bottom: 2.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid var(--medium-gray);
    }

    .sidebar-header h2 {
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-header h2 i {
        font-size: 1.75rem;
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--dark-gray);
        padding: 0.875rem 1.25rem;
        border-radius: var(--border-radius);
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
    }

    .nav-item:hover {
        background-color: var(--primary-light);
        color: var(--primary);
        transform: translateX(5px);
    }

    .nav-item.active {
        background-color: var(--primary-light);
        color: var(--primary);
        font-weight: 600;
    }

    .nav-item i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        margin-top: auto;
        padding-top: 1.5rem;
        border-top: 1px solid var(--medium-gray);
    }

    /* Main Content */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2.5rem;
        transition: margin-left 0.3s ease;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .page-title i {
        color: var(--primary);
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-weight: 600;
    }

    /* Alert Messages */
    .alert {
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        font-size: 0.95rem;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.4s ease;
    }

    .alert.show {
        opacity: 1;
        transform: translateY(0);
    }

    .alert-success {
        background-color: rgba(76, 201, 160, 0.1);
        border: 1px solid var(--success);
        color: var(--success);
    }

    .alert-error {
        background-color: rgba(249, 65, 68, 0.1);
        border: 1px solid var(--danger);
        color: var(--danger);
    }

    .alert i {
        font-size: 1.25rem;
    }

    /* Table Container */
    .table-container {
        background: var(--light);
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--medium-gray);
        overflow: hidden;
        overflow-x: auto;
    }

    /* Table Styles */
    table {
        width: 100%;
        border-collapse: collapse;
    }

    thead {
        background-color: var(--light-gray);
    }

    th, td {
        padding: 1rem 1.25rem;
        text-align: left;
        border-bottom: 1px solid var(--medium-gray);
    }

    th {
        color: var(--dark-gray);
        font-weight: 600;
        font-size: 0.8rem;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    tr:not(:last-child) {
        border-bottom: 1px solid var(--medium-gray);
    }

    tr:hover {
        background-color: var(--light-gray);
    }

    /* Status Badges */
    .status {
        display: inline-flex;
        align-items: center;
        padding: 0.35rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 600;
    }

    .status-new {
        background-color: var(--primary-light);
        color: var(--primary);
    }

    .status-in-progress {
        background-color: var(--warning-light);
        color: var(--warning);
    }

    .status-resolved {
        background-color: var(--success-light);
        color: var(--success);
    }

    /* Action Buttons */
    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }

    .btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 0.5rem 1rem;
        border-radius: var(--border-radius);
        font-size: 0.85rem;
        font-weight: 500;
        cursor: pointer;
        transition: var(--transition);
        text-decoration: none;
        border: none;
        white-space: nowrap;
    }

    .btn-sm {
        padding: 0.375rem 0.75rem;
        font-size: 0.75rem;
    }

    .btn-primary {
        background-color: var(--primary);
        color: var(--light);
    }

    .btn-primary:hover {
        background-color: var(--primary-dark);
        box-shadow: var(--shadow-sm);
    }

    .btn-danger {
        background-color: var(--danger);
        color: var(--light);
    }

    .btn-danger:hover {
        background-color: #dc2626;
        box-shadow: var(--shadow-sm);
    }

    .btn i {
        margin-right: 0.5rem;
        font-size: 0.8em;
    }

    /* File Link */
    .file-link {
        color: var(--primary);
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
        display: inline-flex;
        align-items: center;
        gap: 0.5rem;
    }

    .file-link:hover {
        color: var(--primary-dark);
        text-decoration: underline;
    }

    /* No Complaints Message */
    .no-complaints {
        text-align: center;
        padding: 2rem;
        color: var(--dark-gray);
    }

    .no-complaints i {
        font-size: 1.5rem;
        margin-bottom: 0.5rem;
        color: var(--dark-gray);
    }

    /* Mobile Toggle Button */
    .mobile-toggle {
        display: none;
        position: fixed;
        top: 1rem;
        left: 1rem;
        z-index: 1000;
        background: var(--primary);
        color: var(--light);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-md);
        justify-content: center;
        align-items: center;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
            padding: 1.5rem;
            padding-top: 5rem;
        }

        .mobile-toggle {
            display: flex;
        }
    }

    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
            margin-bottom: 1.5rem;
        }

        .page-title {
            font-size: 1.5rem;
        }

        .user-profile {
            width: 100%;
            justify-content: flex-end;
        }

        th, td {
            padding: 0.75rem;
        }
    }

    @media (max-width: 576px) {
        .main-content {
            padding: 1.25rem;
            padding-top: 5rem;
        }

        .action-buttons {
            flex-direction: column;
            gap: 0.25rem;
        }

        .btn {
            width: 100%;
            justify-content: center;
        }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
    <div class="sidebar-header">
            <h2><i class="fas fa-gavel"></i>Compcure </h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item">
                <i class="fas fa-edit"></i>
                New Complaint
            </a>
            <a href="complaint_table.php" class="nav-item active">
                <i class="fas fa-list"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item">
                <i class="fas fa-comment-alt"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                Help Center
            </a>
            
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-list-check"></i>
                My Complaints
            </h1>
            <div class="user-profile">
               
            </div>
        </div>

        <!-- Success Alert -->
        <?php if (!empty($success_message)): ?>
        <div class="alert alert-success show" id="successAlert">
            <i class="fas fa-check-circle"></i>
            <div><?php echo htmlspecialchars($success_message); ?></div>
        </div>
        <?php endif; ?>
        
        <!-- Error Alert -->
        <?php if (!empty($error_message)): ?>
        <div class="alert alert-error show" id="errorAlert">
            <i class="fas fa-exclamation-circle"></i>
            <div><?php echo htmlspecialchars($error_message); ?></div>
        </div>
        <?php endif; ?>
        
        <div class="table-container">
            <table>
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Name</th>
                        <th>Location</th>
                        <th>Status</th>
                        <th>Attachment</th>
                        <th>Date</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ($result->num_rows > 0): ?>
                        <?php while($row = $result->fetch_assoc()): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($row['title_of_complaint']); ?></td>
                                <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                <td><?php echo htmlspecialchars($row['city']) . ', ' . htmlspecialchars($row['state']); ?></td>
                                <td>
                                    <span class="status status-<?php echo strtolower(str_replace(' ', '-', $row['status'])); ?>">
                                        <?php echo htmlspecialchars($row['status']); ?>
                                    </span>
                                </td>
                                <td>
                                    <?php if ($row['file']): ?>
                                        <a href="../uploads/<?php echo htmlspecialchars($row['file']); ?>" class="file-link" target="_blank">
                                            <i class="fas fa-paperclip"></i> View
                                        </a>
                                    <?php else: ?>
                                        <span class="text-muted">None</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo date('M j, Y', strtotime($row['reg_date'])); ?></td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="register_complaint.php?id=<?php echo $row['id']; ?>" class="btn btn-primary btn-sm">
                                            <i class="fas fa-edit"></i> Edit
                                        </a>
                                        <a href="complaint_table.php?delete_id=<?php echo $row['id']; ?>" 
                                           class="btn btn-danger btn-sm" 
                                           onclick="return confirm('Are you sure you want to delete this complaint?');">
                                            <i class="fas fa-trash"></i> Delete
                                        </a>
                                    </div>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="7">
                                <div class="no-complaints">
                                    <i class="fas fa-info-circle"></i>
                                    <p>No active complaints found</p>
                                </div>
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<script>
    // Mobile Toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');

    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            sidebar.classList.remove('active');
        }
    });

    // Auto-hide alerts after 5 seconds
    const successAlert = document.getElementById('successAlert');
    const errorAlert = document.getElementById('errorAlert');
    
    function fadeOutAlert(alert) {
        if (alert) {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.remove();
                }, 300);
            }, 5000);
        }
    }
    
    fadeOutAlert(successAlert);
    fadeOutAlert(errorAlert);

    // Auto-close sidebar when resizing to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
        }
    });
</script>
</body>
</html>
<?php
$conn->close();
?>