<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM complaints WHERE id='$id'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $id = $_POST['id'];
    $title_of_complaint = $_POST['title_of_complaint'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $nature_of_complaint = $_POST['nature_of_complaint'];
    $details_of_complaint = $_POST['details_of_complaint'];
    $file = $_FILES['file']['name'];

    // File upload handling
    if ($file) {
        $target_dir = "uploads/";
        $target_file = $target_dir . basename($_FILES["file"]["name"]);
        move_uploaded_file($_FILES["file"]["tmp_name"], $target_file);
        $sql = "UPDATE complaints SET title_of_complaint='$title_of_complaint', state='$state', city='$city', nature_of_complaint='$nature_of_complaint', details_of_complaint='$details_of_complaint', file='$file' WHERE id='$id'";
    } else {
        $sql = "UPDATE complaints SET title_of_complaint='$title_of_complaint', state='$state', city='$city', nature_of_complaint='$nature_of_complaint', details_of_complaint='$details_of_complaint' WHERE id='$id'";
    }

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Complaint updated successfully'); window.location.href='complaint_table.php';</script>";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Complaint</title>
</head>
<body style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 0; padding: 0; background-color: #f4f4f4;">

    <div style="display: flex; height: 100vh;">
        <!-- Sidebar -->
        <div style="width: 250px; background-color: #007bff; color: white; padding: 20px; box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);">
            <h2 style="text-align: center;">Dashboard</h2>
            <nav style="margin-top: 30px;">
                <a href="dashboard.php" style="display: block; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; margin-bottom: 10px;">Dashboard</a>
                <a href="register_complaint.php" style="display: block; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; margin-bottom: 10px;">Register Complaint</a>
                <a href="complaint_table.php" style="display: block; color: white; text-decoration: none; padding: 10px 15px; border-radius: 4px; margin-bottom: 10px; background-color: #0056b3;">Complaint Table</a>
            </nav>
        </div>

        <!-- Main Content -->
        <div style="flex: 1; padding: 20px;">
            <h1 style="color: #333;">Update Complaint</h1>
            <form action="update_complaint.php" method="POST" enctype="multipart/form-data" style="background-color: white; padding: 20px; border-radius: 8px; box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);">
                <input type="hidden" name="id" value="<?php echo $row['id']; ?>">
                <div style="margin-bottom: 15px;">
                    <label for="title_of_complaint" style="display: block; color: #333; margin-bottom: 5px;">Title of Complaint:</label>
                    <input type="text" id="title_of_complaint" name="title_of_complaint" value="<?php echo $row['title_of_complaint']; ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="state" style="display: block; color: #333; margin-bottom: 5px;">State:</label>
                    <input type="text" id="state" name="state" value="<?php echo $row['state']; ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="city" style="display: block; color: #333; margin-bottom: 5px;">City:</label>
                    <input type="text" id="city" name="city" value="<?php echo $row['city']; ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="nature_of_complaint" style="display: block; color: #333; margin-bottom: 5px;">Nature of Complaint:</label>
                    <input type="text" id="nature_of_complaint" name="nature_of_complaint" value="<?php echo $row['nature_of_complaint']; ?>" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="details_of_complaint" style="display: block; color: #333; margin-bottom: 5px;">Details of Complaint:</label>
                    <textarea id="details_of_complaint" name="details_of_complaint" required style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;"><?php echo $row['details_of_complaint']; ?></textarea>
                </div>
                <div style="margin-bottom: 15px;">
                    <label for="file" style="display: block; color: #333; margin-bottom: 5px;">Upload File (Optional):</label>
                    <input type="file" id="file" name="file" style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 4px;">
                </div>
                <div style="text-align: center;">
                    <button type="submit" style="background-color: #007bff; color: white; padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer;">Update Complaint</button>
                </div>
            </form>
        </div>
    </div>

</body>
</html>