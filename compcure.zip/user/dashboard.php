<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$sql_user = "SELECT username, email FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user_details = $result_user->fetch_assoc();
$stmt_user->close();

// Count complaints by status for the logged-in user
$sql_submitted = "SELECT COUNT(*) as count FROM complaints WHERE user_id = ?";
$sql_in_progress = "SELECT COUNT(*) as count FROM complaints WHERE status = 'In Progress' AND user_id = ?";
$sql_completed = "SELECT COUNT(*) as count FROM complaints WHERE status = 'Completed' AND user_id = ?";

$stmt_submitted = $conn->prepare($sql_submitted);
$stmt_submitted->bind_param("i", $user_id);
$stmt_submitted->execute();
$result_submitted = $stmt_submitted->get_result();
$count_submitted = $result_submitted->fetch_assoc()['count'];

$stmt_in_progress = $conn->prepare($sql_in_progress);
$stmt_in_progress->bind_param("i", $user_id);
$stmt_in_progress->execute();
$result_in_progress = $stmt_in_progress->get_result();
$count_in_progress = $result_in_progress->fetch_assoc()['count'];

$stmt_completed = $conn->prepare($sql_completed);
$stmt_completed->bind_param("i", $user_id);
$stmt_completed->execute();
$result_completed = $stmt_completed->get_result();
$count_completed = $result_completed->fetch_assoc()['count'];

$stmt_submitted->close();
$stmt_in_progress->close();
$stmt_completed->close();

// Fetch the latest admin reply for the logged-in user
$sql_latest_reply = "SELECT subject, reply FROM help_requests WHERE user_id = ? AND reply IS NOT NULL ORDER BY id DESC LIMIT 1";
$stmt_latest_reply = $conn->prepare($sql_latest_reply);
$stmt_latest_reply->bind_param("i", $user_id);
$stmt_latest_reply->execute();
$result_latest_reply = $stmt_latest_reply->get_result();
$latest_reply = $result_latest_reply->fetch_assoc();
$stmt_latest_reply->close();

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5.0">
    <title>Complaint Management Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
    :root {
        --primary: #4F46E5;
        --primary-hover: #4338CA;
        --secondary: #6366F1;
        --success: #10B981;
        --warning: #F59E0B;
        --danger: #EF4444;
        --light: #FFFFFF;
        --dark: #111827;
        --gray-100: #F9FAFB;
        --gray-200: #E5E7EB;
        --gray-500: #6B7280;
        --shadow-sm: 0 1px 2px rgba(0,0,0,0.05);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.05);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --radius-md: 12px;
        --radius-lg: 16px;
        --transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background: var(--gray-100);
        color: var(--dark);
        line-height: 1.5;
        -webkit-font-smoothing: antialiased;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
        position: relative;
    }

    /* Modern Light Sidebar */
    .dashboard-sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 1000;
        transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1);
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--gray-200);
        display: flex;
        flex-direction: column;
    }

    .sidebar-profile {
        text-align: center;
        padding: 1.5rem;
        margin-bottom: 2rem;
        background: var(--light);
        border-radius: var(--radius-md);
        box-shadow: var(--shadow-sm);
        position: relative;
        overflow: hidden;
    }

    .profile-avatar {
        width: 96px;
        height: 96px;
        border-radius: 50%;
        margin: 0 auto 1.5rem;
        overflow: hidden;
        border: 3px solid var(--primary);
        transition: var(--transition);
    }

    .profile-avatar:hover {
        transform: scale(1.05);
        box-shadow: 0 8px 16px rgba(79, 70, 229, 0.1);
    }

    .profile-info h3 {
        color: var(--dark);
        font-size: 1.25rem;
        font-weight: 600;
        margin-bottom: 0.25rem;
    }

    .profile-info p {
        color: var(--gray-500);
        font-size: 0.875rem;
    }

    .view-profile-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.5rem;
        padding: 0.75rem 1.5rem;
        background: var(--primary);
        color: var(--light);
        border-radius: var(--radius-md);
        text-decoration: none;
        margin-top: 1rem;
        transition: var(--transition);
        font-weight: 500;
        width: 100%;
        box-shadow: var(--shadow-sm);
    }

    .view-profile-btn:hover {
        background: var(--primary-hover);
        transform: translateY(-2px);
        box-shadow: var(--shadow-md);
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        flex: 1;
        overflow-y: auto;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--gray-500);
        padding: 1rem 1.25rem;
        border-radius: var(--radius-md);
        text-decoration: none;
        transition: var(--transition);
        position: relative;
        font-weight: 500;
    }

    .nav-item:hover,
    .nav-item.active {
        background: rgba(79, 70, 229, 0.05);
        color: var(--primary);
    }

    .nav-item.active::before {
        content: '';
        position: absolute;
        left: -8px;
        height: 60%;
        width: 3px;
        background: var(--primary);
        border-radius: 2px;
    }

    /* Main Content Area */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 3rem;
        transition: margin 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    }

    /* Dashboard Header */
    .dashboard-header {
        margin-bottom: 3rem;
        padding: 2rem;
        background: var(--light);
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        animation: slideIn 0.6s ease;
    }

    .user-greeting h1 {
        font-size: 2rem;
        font-weight: 700;
        color: var(--dark);
        letter-spacing: -0.025em;
    }

    .user-greeting p {
        color: var(--gray-500);
        font-size: 1rem;
    }

    /* Enhanced Stats Grid */
    .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 2rem;
        margin-bottom: 3rem;
    }

    .stat-card {
        background: var(--light);
        padding: 2rem;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        transition: var(--transition);
        position: relative;
        overflow: hidden;
        border-left: 4px solid var(--primary);
    }

    .stat-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-lg);
    }

    .stat-header {
        display: flex;
        align-items: center;
        gap: 1.25rem;
        margin-bottom: 1.5rem;
    }

    .stat-icon {
        width: 56px;
        height: 56px;
        border-radius: 12px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.75rem;
        background: rgba(79, 70, 229, 0.1);
        color: var(--primary);
    }

    .stat-content h3 {
        font-size: 1.125rem;
        color: var(--gray-500);
        margin-bottom: 0.25rem;
    }

    .stat-value {
        font-size: 2.5rem;
        font-weight: 700;
        color: var(--dark);
        line-height: 1;
    }

    /* Latest Update Card */
    .update-card {
        background: var(--light);
        padding: 2rem;
        border-radius: var(--radius-lg);
        box-shadow: var(--shadow-sm);
        animation: fadeIn 0.6s ease;
        border-top: 4px solid var(--primary);
    }

    .update-header {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-bottom: 1.5rem;
    }

    .update-icon {
        width: 48px;
        height: 48px;
        border-radius: 50%;
        background: var(--primary);
        color: var(--light);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.5rem;
    }

    .update-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--dark);
        margin-bottom: 0.5rem;
    }

    .update-content {
        color: var(--gray-500);
        line-height: 1.6;
    }

    /* Notification Badge */
    .notification-badge {
        position: fixed;
        bottom: 2rem;
        right: 2rem;
        background: var(--primary);
        color: white;
        width: 56px;
        height: 56px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        box-shadow: var(--shadow-lg);
        cursor: pointer;
        transition: var(--transition);
        z-index: 1000;
        animation: pulse 2s infinite;
    }

    .notification-badge:hover {
        transform: scale(1.1);
    }

    @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
    }

    /* Logout Button Styling */
    .sidebar-footer {
        margin-top: auto;
        padding-top: 2rem;
        border-top: 1px solid var(--gray-200);
    }

    .sidebar-footer .nav-item {
        background: rgba(239, 68, 68, 0.1);
        color: var(--danger);
    }

    .sidebar-footer .nav-item:hover {
        background: rgba(239, 68, 68, 0.2);
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .dashboard-sidebar {
            transform: translateX(-100%);
            width: 300px;
        }

        .main-content {
            margin-left: 0;
            padding: 2rem;
        }

        .mobile-menu-toggle {
            display: flex;
            align-items: center;
            justify-content: center;
            position: fixed;
            top: 1.5rem;
            left: 1.5rem;
            z-index: 1000;
            background: var(--primary);
            color: var(--light);
            border: none;
            padding: 1rem;
            border-radius: 12px;
            width: 48px;
            height: 48px;
            box-shadow: var(--shadow-lg);
            transition: var(--transition);
        }

        .sidebar-open .dashboard-sidebar {
            transform: translateX(0);
        }
    }

    @keyframes slideIn {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    @keyframes fadeIn {
        from { opacity: 0; transform: translateX(-20px); }
        to { opacity: 1; transform: translateX(0); }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <button class="mobile-menu-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <aside class="dashboard-sidebar">
        <div class="sidebar-profile">
            <div class="profile-avatar">
                <img src="https://ui-avatars.com/api/?name=<?= urlencode($user_details['username']) ?>&background=4F46E5&color=fff" alt="Profile">
            </div>
            <div class="profile-info">
                <h3><?= htmlspecialchars($user_details['username']) ?></h3>
                <p><?= htmlspecialchars($user_details['email']) ?></p>
            </div>
            <a href="profile.php" class="view-profile-btn">
                <i class="fas fa-user-cog"></i>
                View Profile
            </a>
        </div>

        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item active">
                <i class="fas fa-chart-line"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item">
                <i class="fas fa-pen-to-square"></i>
                New Complaint
            </a>
            <a href="complaint_table.php" class="nav-item">
                <i class="fas fa-table-cells"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item">
                <i class="fas fa-comment-dots"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item">
                <i class="fas fa-circle-question"></i>
                Help Center
            </a>
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-arrow-right-from-bracket"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <main class="main-content">
        <header class="dashboard-header">
            <div class="user-greeting">
                <h1>Welcome, <?php echo htmlspecialchars($user_details['username']); ?></h1>
                <p>Complaint Management Dashboard</p>
            </div>
        </header>

        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="fas fa-paper-plane"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Submitted Complaints</h3>
                        <p class="stat-value"><?php echo $count_submitted; ?></p>
                    </div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="fas fa-gears"></i>
                    </div>
                    <div class="stat-content">
                        <h3>In Progress</h3>
                        <p class="stat-value"><?php echo $count_in_progress; ?></p>
                    </div>
                </div>
            </div>

            <div class="stat-card">
                <div class="stat-header">
                    <div class="stat-icon">
                        <i class="fas fa-check-double"></i>
                    </div>
                    <div class="stat-content">
                        <h3>Resolved</h3>
                        <p class="stat-value"><?php echo $count_completed; ?></p>
                    </div>
                </div>
            </div>
        </div>

        <div class="update-card">
            <div class="update-header">
                <div class="update-icon">
                    <i class="fas fa-bullhorn"></i>
                </div>
                <h2>Latest Update</h2>
            </div>
            <div id="latestUpdateContent">
                <?php if(isset($latest_reply)): ?>
                    <p class="update-title"><?php echo htmlspecialchars($latest_reply['subject']); ?></p>
                    <p class="update-content"><?php echo htmlspecialchars($latest_reply['reply']); ?></p>
                <?php else: ?>
                    <p class="update-content">No recent updates available</p>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <div class="notification-badge" id="notificationBadge">
        <i class="fas fa-bell"></i>
    </div>
</div>

<script>
    const mobileToggle = document.getElementById('mobileToggle');
    const dashboardContainer = document.querySelector('.dashboard-container');

    mobileToggle.addEventListener('click', () => {
        dashboardContainer.classList.toggle('sidebar-open');
    });

    document.addEventListener('click', (e) => {
        const sidebar = document.querySelector('.dashboard-sidebar');
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            dashboardContainer.classList.remove('sidebar-open');
        }
    });
</script>
</body>
</html>