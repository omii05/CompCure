<?php
$host = "localhost"; 
$user = "root"; 
$password = ""; 
$database = "complaint_system"; // Replace with your actual database name

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_name = $_POST["user_name"];
    $rating = $_POST["rating"];
    $feedback = $_POST["feedback"];

    if ($rating < 1 || $rating > 5) {
        die("Invalid rating value.");
    }

    $stmt = $conn->prepare("INSERT INTO feedback (user_name, rating, feedback) VALUES (?, ?, ?)");
    $stmt->bind_param("sis", $user_name, $rating, $feedback);

    if ($stmt->execute()) {
        echo "<script>alert('Feedback submitted successfully!'); window.location.href='feedback_form.php';</script>";
    } else {
        echo "Error: " . $stmt->error;
    }

    $stmt->close();
}

$conn->close();
?>
