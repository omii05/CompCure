<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch user details
$sql_user = "SELECT username, email, profile_image FROM users WHERE id = ?";
$stmt_user = $conn->prepare($sql_user);
$stmt_user->bind_param("i", $user_id);
$stmt_user->execute();
$result_user = $stmt_user->get_result();
$user_details = $result_user->fetch_assoc();
$stmt_user->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Jacques+Francois+Shadow&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: linear-gradient(135deg, #667eea, #764ba2);
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .profile-container {
            background-color: white;
            color: black;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.5);
            text-align: center;
            width: 300px;
        }
        .profile-container img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            margin-bottom: 10px;
        }
        .profile-container .update-btn, .profile-container .delete-btn {
            background-color: #4B0082;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .profile-container .delete-btn {
            background-color: red;
        }
        .profile-container .close-btn {
            background-color: red;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-top: 10px;
        }
        .profile-container form {
            display: none;
        }
    </style>
    <script>
        function showUpdateForm() {
            document.getElementById('profileImageForm').style.display = 'block';
        }

        function showEmailForm() {
            document.getElementById('emailForm').style.display = 'block';
        }

        function deleteProfileImage() {
            if (confirm('Are you sure you want to delete your profile image?')) {
                document.getElementById('deleteProfileImageForm').submit();
            }
        }
    </script>
</head>
<body>
    

<div class="profile-container">
    <h2>User Profile</h2>
    <?php if ($user_details['profile_image']): ?>
        <img src="../<?php echo $user_details['profile_image']; ?>" alt="Profile Image">
    <?php else: ?>
        <img src="default_profile.png" alt="Default Profile Image">
    <?php endif; ?>
    <p><strong>Username:</strong> <?php echo $user_details['username']; ?></p>
    <p><strong>Email:</strong> <?php echo $user_details['email']; ?></p>
    <button class="update-btn" onclick="showUpdateForm()">Upload Profile Image</button>
    <button class="delete-btn" onclick="deleteProfileImage()">Delete Profile Image</button>
   
    <button class="close-btn" onclick="window.location.href='dashboard.php'">Close</button>

    <!-- Form to update profile image -->
    <form id="profileImageForm" action="update_profile_image.php" method="post" enctype="multipart/form-data">
        <input type="file" name="profile_image" required>
        <button type="submit" class="update-btn">Upload</button>
    </form>

    <!-- Form to delete profile image -->
    <form id="deleteProfileImageForm" action="delete_profile_image.php" method="post">
        <input type="hidden" name="user_id" value="<?php echo $user_id; ?>">
    </form>

    
</div>

</body>
</html>