<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize messages
$success_message = '';
$error_message = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $subject = $conn->real_escape_string($_POST['subject']);
    $message = $conn->real_escape_string($_POST['message']);

    $sql = "INSERT INTO help_requests (user_id, subject, message, status) VALUES (?, ?, ?, 'Pending')";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("iss", $user_id, $subject, $message);
    if ($stmt->execute()) {
        $_SESSION['success_message'] = "Your help request has been sent successfully!";
    } else {
        $_SESSION['error_message'] = "Failed to send your help request. Please try again.";
    }
    $stmt->close();
    header("Location: help.php");
    exit();
}

// Check for messages in session
if (isset($_SESSION['success_message'])) {
    $success_message = $_SESSION['success_message'];
    unset($_SESSION['success_message']);
}
if (isset($_SESSION['error_message'])) {
    $error_message = $_SESSION['error_message'];
    unset($_SESSION['error_message']);
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Help Center | Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --primary-light: #e6ebfd;
        --secondary: #3f37c9;
        --success: #4cc9a0;
        --success-light: #e6f7f1;
        --warning: #f8961e;
        --warning-light: #fef3e6;
        --danger: #f94144;
        --danger-light: #fee6e7;
        --light: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #6c757d;
        --dark: #212529;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        --border-radius: 0.5rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background-color: var(--light-gray);
        color: var(--dark);
        line-height: 1.6;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    /* Modern Sidebar */
    .sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 100;
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--medium-gray);
        transition: transform 0.3s ease;
    }

    .sidebar-header {
        margin-bottom: 2.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid var(--medium-gray);
    }

    .sidebar-header h2 {
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-header h2 i {
        font-size: 1.75rem;
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--dark-gray);
        padding: 0.875rem 1.25rem;
        border-radius: var(--border-radius);
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
    }

    .nav-item:hover {
        background-color: var(--primary-light);
        color: var(--primary);
        transform: translateX(5px);
    }

    .nav-item.active {
        background-color: var(--primary-light);
        color: var(--primary);
        font-weight: 600;
    }

    .nav-item i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        margin-top: auto;
        padding-top: 1.5rem;
        border-top: 1px solid var(--medium-gray);
    }

    /* Main Content */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2.5rem;
        transition: margin-left 0.3s ease;
        display: flex;
        justify-content: center;
        align-items: center;
        min-height: 100vh;
    }

    /* Help Form Container */
    .help-card {
        background: var(--light);
        padding: 2.5rem;
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--medium-gray);
        width: 100%;
        max-width: 600px;
        animation: fadeInUp 0.5s ease-out;
    }

    .help-header {
        text-align: center;
        margin-bottom: 2rem;
    }

    .help-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
    }

    .help-header p {
        color: var(--dark-gray);
        margin-top: 0.5rem;
    }

    /* Alert Messages */
    .alert {
        padding: 1rem 1.5rem;
        border-radius: var(--border-radius);
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        font-size: 0.95rem;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.4s ease;
    }

    .alert.show {
        opacity: 1;
        transform: translateY(0);
    }

    .alert-success {
        background-color: rgba(76, 201, 160, 0.1);
        border: 1px solid var(--success);
        color: var(--success);
    }

    .alert-error {
        background-color: rgba(249, 65, 68, 0.1);
        border: 1px solid var(--danger);
        color: var(--danger);
    }

    .alert i {
        font-size: 1.25rem;
    }

    /* Form Elements */
    .form-group {
        margin-bottom: 1.5rem;
    }

    label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--dark);
        font-weight: 500;
    }

    input, textarea {
        width: 100%;
        padding: 0.875rem 1.25rem;
        border: 1px solid var(--medium-gray);
        border-radius: var(--border-radius);
        background: var(--light);
        transition: var(--transition);
    }

    input:focus, textarea:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
        outline: none;
    }

    textarea {
        min-height: 150px;
        resize: vertical;
    }

    /* Submit Button */
    .submit-btn {
        background: var(--primary);
        color: var(--light);
        padding: 1rem 2rem;
        border: none;
        border-radius: var(--border-radius);
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: var(--transition);
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        position: relative;
        overflow: hidden;
    }

    .submit-btn:hover {
        background: var(--primary-dark);
        box-shadow: var(--shadow-md);
    }

    .submit-btn .button-text {
        transition: opacity 0.3s ease;
    }

    .submit-btn .loading-spinner {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 24px;
        height: 24px;
        border: 3px solid rgba(255, 255, 255, 0.3);
        border-radius: 50%;
        border-top-color: #fff;
        animation: spin 1s linear infinite;
        opacity: 0;
        transition: opacity 0.3s ease;
    }

    .submit-btn.loading .button-text {
        opacity: 0;
    }

    .submit-btn.loading .loading-spinner {
        opacity: 1;
    }

    @keyframes spin {
        0% { transform: translate(-50%, -50%) rotate(0deg); }
        100% { transform: translate(-50%, -50%) rotate(360deg); }
    }

    @keyframes fadeInUp {
        from { opacity: 0; transform: translateY(20px); }
        to { opacity: 1; transform: translateY(0); }
    }

    /* Mobile Toggle Button */
    .mobile-toggle {
        display: none;
        position: fixed;
        top: 1rem;
        left: 1rem;
        z-index: 1000;
        background: var(--primary);
        color: var(--light);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-md);
        justify-content: center;
        align-items: center;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
            padding: 1.5rem;
        }

        .mobile-toggle {
            display: flex;
        }

        .help-card {
            padding: 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .help-header h1 {
            font-size: 1.5rem;
        }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-gavel"></i> CompCure</h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item">
                <i class="fas fa-edit"></i>
                New Complaint
            </a>
            <a href="complaint_table.php" class="nav-item">
                <i class="fas fa-list"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item">
                <i class="fas fa-comment-alt"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item active">
                <i class="fas fa-question-circle"></i>
                Help Center
            </a>
            
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="help-card">
            <div class="help-header">
                <h1><i class="fas fa-question-circle"></i> Help Center</h1>
                <p>We're here to assist you with any issues or questions</p>
            </div>

            <!-- Success Alert -->
            <?php if (!empty($success_message)): ?>
            <div class="alert alert-success show" id="successAlert">
                <i class="fas fa-check-circle"></i>
                <div><?php echo htmlspecialchars($success_message); ?></div>
            </div>
            <?php endif; ?>
            
            <!-- Error Alert -->
            <?php if (!empty($error_message)): ?>
            <div class="alert alert-error show" id="errorAlert">
                <i class="fas fa-exclamation-circle"></i>
                <div><?php echo htmlspecialchars($error_message); ?></div>
            </div>
            <?php endif; ?>

            <form id="helpForm" method="POST">
                <div class="form-group">
                    <label for="subject">Subject</label>
                    <input type="text" id="subject" name="subject" placeholder="What's this about?" required>
                </div>

                <div class="form-group">
                    <label for="message">Your Message</label>
                    <textarea id="message" name="message" placeholder="Describe your issue in detail..." required></textarea>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn">
                    <span class="button-text">Send Request</span>
                    <div class="loading-spinner"></div>
                </button>
            </form>
        </div>
    </main>
</div>

<script>
    // Mobile Toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');

    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            sidebar.classList.remove('active');
        }
    });

    // Form submission with loading animation
    const helpForm = document.getElementById('helpForm');
    const submitBtn = document.getElementById('submitBtn');

    helpForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading state
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;

        // Hide alerts
        const successAlert = document.getElementById('successAlert');
        const errorAlert = document.getElementById('errorAlert');
        if (successAlert) successAlert.classList.remove('show');
        if (errorAlert) errorAlert.classList.remove('show');

        // Simulate 3-second processing time
        setTimeout(() => {
            // Submit the form after animation
            this.submit();
        }, 3000);
    });

    // Auto-hide alerts after 5 seconds
    const successAlert = document.getElementById('successAlert');
    const errorAlert = document.getElementById('errorAlert');
    
    function fadeOutAlert(alert) {
        if (alert) {
            setTimeout(() => {
                alert.style.opacity = '0';
                setTimeout(() => {
                    alert.remove();
                }, 300);
            }, 5000);
        }
    }
    
    fadeOutAlert(successAlert);
    fadeOutAlert(errorAlert);

    // Auto-close sidebar when resizing to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
        }
    });
</script>
</body>
</html>