<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize variables
$is_update = false;
$full_name = '';
$title_of_complaint = '';
$state = '';
$city = '';
$details_of_complaint = '';
$file = '';

// Check if updating an existing complaint
if (isset($_GET['id'])) {
    $is_update = true;
    $id = $_GET['id'];
    $sql = "SELECT * FROM complaints WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $complaint = $result->fetch_assoc();
        $full_name = $complaint['full_name'];
        $title_of_complaint = $complaint['title_of_complaint'];
        $state = $complaint['state'];
        $city = $complaint['city'];
        $details_of_complaint = $complaint['details_of_complaint'];
        $file = $complaint['file'];
    }
    $stmt->close();
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $full_name = $_POST['full_name'];
    $title_of_complaint = $_POST['title_of_complaint'];
    $details_of_complaint = $_POST['details_of_complaint'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $file = $_FILES['file']['name'];

    // Handle file upload
    if ($file) {
        $upload_dir = '../uploads/';
        $file_path = $upload_dir . basename($file);
        if (move_uploaded_file($_FILES['file']['tmp_name'], $file_path)) {
            // File uploaded successfully
        } else {
            echo "Error uploading file.";
        }
    }

    if ($is_update) {
        // Update existing complaint
        $sql = "UPDATE complaints SET full_name = ?, title_of_complaint = ?, details_of_complaint = ?, state = ?, city = ?, file = ? WHERE id = ? AND user_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssssssii", $full_name, $title_of_complaint, $details_of_complaint, $state, $city, $file, $id, $user_id);
    } else {
        // Create new complaint
        $sql = "INSERT INTO complaints (user_id, full_name, title_of_complaint, details_of_complaint, state, city, file, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'New')";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("issssss", $user_id, $full_name, $title_of_complaint, $details_of_complaint, $state, $city, $file);
    }

    $stmt->execute();
    $stmt->close();

    header("Location: /final/user/dashboard.php");
    exit();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $is_update ? 'Update Complaint' : 'Register Complaint'; ?> | Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --primary-light: #e6ebfd;
        --secondary: #3f37c9;
        --success: #4cc9a0;
        --warning: #f8961e;
        --danger: #f94144;
        --light: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #6c757d;
        --dark: #212529;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.12);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background-color: var(--light-gray);
        color: var(--dark);
        line-height: 1.6;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    /* Modern Sidebar */
    .sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 100;
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--medium-gray);
        transition: transform 0.3s ease;
    }

    .sidebar-header {
        margin-bottom: 2.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid var(--medium-gray);
    }

    .sidebar-header h2 {
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-header h2 i {
        font-size: 1.75rem;
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--dark-gray);
        padding: 0.875rem 1.25rem;
        border-radius: 0.5rem;
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
    }

    .nav-item:hover {
        background-color: var(--primary-light);
        color: var(--primary);
        transform: translateX(5px);
    }

    .nav-item.active {
        background-color: var(--primary-light);
        color: var(--primary);
        font-weight: 600;
    }

    .nav-item i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        margin-top: auto;
        padding-top: 1.5rem;
        border-top: 1px solid var(--medium-gray);
    }

    /* Main Content */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2.5rem;
        transition: margin-left 0.3s ease;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .page-title i {
        color: var(--primary);
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-weight: 600;
    }

    /* Form Card */
    .form-card {
        background: var(--light);
        padding: 2.5rem;
        border-radius: 0.75rem;
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--medium-gray);
        max-width: 800px;
        margin: 0 auto;
    }

    .form-header {
        margin-bottom: 2rem;
        text-align: center;
    }

    .form-header h1 {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 0.5rem;
    }

    .form-header p {
        color: var(--dark-gray);
        font-size: 0.95rem;
    }

    .form-group {
        margin-bottom: 1.75rem;
    }

    .form-group label {
        display: block;
        margin-bottom: 0.5rem;
        color: var(--dark);
        font-weight: 500;
        font-size: 0.95rem;
    }

    .form-control {
        width: 100%;
        padding: 0.875rem 1.25rem;
        border: 1px solid var(--medium-gray);
        border-radius: 0.5rem;
        background: var(--light);
        font-size: 0.95rem;
        transition: var(--transition);
    }

    .form-control:focus {
        border-color: var(--primary);
        box-shadow: 0 0 0 3px var(--primary-light);
        outline: none;
    }

    textarea.form-control {
        min-height: 150px;
        resize: vertical;
    }

    /* File Upload */
    .file-upload {
        position: relative;
        margin-top: 0.5rem;
    }

    .file-upload input[type="file"] {
        position: absolute;
        left: 0;
        top: 0;
        opacity: 0;
        width: 100%;
        height: 100%;
        cursor: pointer;
    }

    .file-upload-label {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        padding: 1.25rem;
        background: var(--light-gray);
        border: 2px dashed var(--medium-gray);
        border-radius: 0.5rem;
        color: var(--dark-gray);
        cursor: pointer;
        transition: var(--transition);
        text-align: center;
    }

    .file-upload-label:hover {
        border-color: var(--primary);
        background: var(--primary-light);
        color: var(--primary);
    }

    .file-upload-label i {
        font-size: 1.5rem;
    }

    .current-file {
        margin-top: 0.75rem;
        font-size: 0.9rem;
        color: var(--dark-gray);
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .current-file a {
        color: var(--primary);
        text-decoration: none;
        transition: var(--transition);
    }

    .current-file a:hover {
        text-decoration: underline;
    }

    /* Submit Button */
    .submit-btn {
        background: var(--primary);
        color: var(--light);
        padding: 1rem 2rem;
        border: none;
        border-radius: 0.5rem;
        font-weight: 600;
        font-size: 1rem;
        cursor: pointer;
        transition: var(--transition);
        width: 100%;
        margin-top: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 0.75rem;
        position: relative;
        overflow: hidden;
    }

    .submit-btn:hover {
        background: var(--primary-dark);
        box-shadow: var(--shadow-md);
        transform: translateY(-2px);
    }

    .submit-btn:active {
        transform: translateY(0);
    }

    .submit-btn i {
        transition: var(--transition);
    }

    .submit-btn.loading i {
        opacity: 0;
    }

    /* Button Loading Animation */
    .submit-btn::after {
        content: "";
        position: absolute;
        width: 20px;
        height: 20px;
        border: 3px solid transparent;
        border-top-color: var(--light);
        border-radius: 50%;
        animation: spin 1s linear infinite;
        opacity: 0;
        transition: var(--transition);
    }

    .submit-btn.loading::after {
        opacity: 1;
    }

    @keyframes spin {
        0% { transform: rotate(0deg); }
        100% { transform: rotate(360deg); }
    }

    /* Success Message */
    .alert {
        padding: 1rem 1.5rem;
        border-radius: 0.5rem;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        font-size: 0.95rem;
        opacity: 0;
        transform: translateY(-20px);
        transition: all 0.4s ease;
    }

    .alert.show {
        opacity: 1;
        transform: translateY(0);
    }

    .alert-success {
        background-color: rgba(76, 201, 160, 0.1);
        border: 1px solid var(--success);
        color: var(--success);
    }

    .alert i {
        font-size: 1.25rem;
    }

    /* Mobile Toggle Button */
    .mobile-toggle {
        display: none;
        position: fixed;
        top: 1rem;
        left: 1rem;
        z-index: 1000;
        background: var(--primary);
        color: var(--light);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-md);
        justify-content: center;
        align-items: center;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
            padding: 1.5rem;
        }

        .mobile-toggle {
            display: flex;
        }

        .form-card {
            padding: 1.5rem;
        }
    }

    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }

        .user-profile {
            width: 100%;
            justify-content: flex-end;
        }
    }

    @media (max-width: 576px) {
        .main-content {
            padding: 1.25rem;
        }

        .form-header h1 {
            font-size: 1.5rem;
        }

        .form-group {
            margin-bottom: 1.25rem;
        }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-gavel"></i>Compcure </h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item active">
                <i class="fas fa-edit"></i>
                <?php echo $is_update ? 'Update Complaint' : 'New Complaint'; ?>
            </a>
            <a href="complaint_table.php" class="nav-item">
                <i class="fas fa-list"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item">
                <i class="fas fa-comment-alt"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                Help Center
            </a>
            
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <h1 class="page-title">
                <i class="fas fa-edit"></i>
                <?php echo $is_update ? 'Update Complaint' : 'Register New Complaint'; ?>
            </h1>
            
        </div>

        <!-- Success Alert -->
        <div class="alert alert-success" id="successAlert">
            <i class="fas fa-check-circle"></i>
            <div>
                <strong>Success!</strong> 
                <span id="successMessage"><?php echo $is_update ? 'Complaint updated successfully!' : 'Complaint submitted successfully!'; ?></span>
            </div>
        </div>

        <div class="form-card">
            <div class="form-header">
                <h1><?php echo $is_update ? 'Update Your Complaint' : 'File a New Complaint'; ?></h1>
                <p><?php echo $is_update ? 'Modify the details of your existing complaint' : 'Fill out the form below to register your complaint'; ?></p>
            </div>
            
            <form id="complaintForm" action="register_complaint.php<?php echo $is_update ? '?id=' . $id : ''; ?>" method="post" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="full_name">Full Name</label>
                    <input type="text" class="form-control" id="full_name" name="full_name" value="<?php echo htmlspecialchars($full_name); ?>" required>
                </div>

                <div class="form-group">
                    <label for="title_of_complaint">Complaint Title</label>
                    <input type="text" class="form-control" id="title_of_complaint" name="title_of_complaint" value="<?php echo htmlspecialchars($title_of_complaint); ?>" required>
                </div>

                <div class="form-group">
                    <label for="state">State</label>
                    <input type="text" class="form-control" id="state" name="state" value="<?php echo htmlspecialchars($state); ?>" required>
                </div>

                <div class="form-group">
                    <label for="city">City</label>
                    <input type="text" class="form-control" id="city" name="city" value="<?php echo htmlspecialchars($city); ?>" required>
                </div>

                <div class="form-group">
                    <label for="details_of_complaint">Complaint Details</label>
                    <textarea class="form-control" id="details_of_complaint" name="details_of_complaint" rows="6" required><?php echo htmlspecialchars($details_of_complaint); ?></textarea>
                </div>

                <div class="form-group">
                    <label>Attach Supporting Document</label>
                    <div class="file-upload">
                        <label class="file-upload-label">
                            <i class="fas fa-cloud-upload-alt"></i>
                            <span id="fileLabel"><?php echo $file ? 'Change File' : 'Choose File (PDF, JPG, PNG)' ?></span>
                        </label>
                        <input type="file" name="file" id="file" accept=".pdf,.jpg,.jpeg,.png">
                    </div>
                    <?php if ($file): ?>
                        <p class="current-file">
                            <i class="fas fa-paperclip"></i>
                            Current file: <a href="../uploads/<?php echo htmlspecialchars($file); ?>" target="_blank"><?php echo htmlspecialchars($file); ?></a>
                        </p>
                    <?php endif; ?>
                </div>

                <button type="submit" class="submit-btn" id="submitBtn">
                    <i class="fas <?php echo $is_update ? 'fa-sync-alt' : 'fa-paper-plane'; ?>"></i>
                    <?php echo $is_update ? 'Update Complaint' : 'Submit Complaint' ?>
                </button>
            </form>
        </div>
    </main>
</div>

<script>
    // Mobile Toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');

    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            sidebar.classList.remove('active');
        }
    });

    // File Input Change
    const fileInput = document.getElementById('file');
    const fileLabel = document.getElementById('fileLabel');

    fileInput.addEventListener('change', (e) => {
        if(fileInput.files.length > 0) {
            fileLabel.textContent = fileInput.files[0].name;
        } else {
            fileLabel.textContent = '<?php echo $file ? "Change File" : "Choose File (PDF, JPG, PNG)"; ?>';
        }
    });

    // Form Submission with Loading Animation
    const complaintForm = document.getElementById('complaintForm');
    const submitBtn = document.getElementById('submitBtn');
    const successAlert = document.getElementById('successAlert');

    complaintForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Show loading state on button
        submitBtn.classList.add('loading');
        submitBtn.disabled = true;
        
        // Hide success alert if visible
        successAlert.classList.remove('show');
        
        // Simulate processing delay (4 seconds)
        setTimeout(() => {
            // Remove loading state
            submitBtn.classList.remove('loading');
            
            // Show success message
            successAlert.classList.add('show');
            
            // Scroll to success message
            successAlert.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            
            // Actually submit the form after showing the success message
            setTimeout(() => {
                this.submit();
            }, 1500);
        }, 4000);
    });

    // Prevent form resubmission on page refresh
    if (window.history.replaceState) {
        window.history.replaceState(null, null, window.location.href);
    }

    // Initialize tooltips (if you add any later)
    document.addEventListener('DOMContentLoaded', function() {
        const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
        tooltipTriggerList.map(function (tooltipTriggerEl) {
            return new bootstrap.Tooltip(tooltipTriggerEl);
        });
    });
</script>
</body>
</html>