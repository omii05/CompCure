<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli($servername, $username, $password, $dbname);
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch current profile image
    $sql = "SELECT profile_image FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();

    // Delete profile image file
    if ($user['profile_image'] && file_exists($user['profile_image'])) {
        unlink($user['profile_image']);
    }

    // Update profile image in database
    $sql = "UPDATE users SET profile_image = NULL WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $stmt->close();
    $conn->close();

    header("Location: profile.php");
}
?>