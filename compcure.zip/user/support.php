<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Support Center | Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4361ee;
        --primary-dark: #3a56d4;
        --primary-light: #e6ebfd;
        --secondary: #3f37c9;
        --success: #4cc9a0;
        --success-light: #e6f7f1;
        --warning: #f8961e;
        --warning-light: #fef3e6;
        --danger: #f94144;
        --danger-light: #fee6e7;
        --light: #ffffff;
        --light-gray: #f8f9fa;
        --medium-gray: #e9ecef;
        --dark-gray: #6c757d;
        --dark: #212529;
        --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
        --shadow-md: 0 4px 6px rgba(0,0,0,0.1);
        --shadow-lg: 0 10px 15px rgba(0,0,0,0.1);
        --transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
        --border-radius: 0.5rem;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
        font-family: 'Inter', sans-serif;
    }

    body {
        background-color: var(--light-gray);
        color: var(--dark);
        line-height: 1.6;
    }

    .dashboard-container {
        display: flex;
        min-height: 100vh;
    }

    /* Modern Sidebar */
    .sidebar {
        width: 280px;
        background: var(--light);
        padding: 2rem 1.5rem;
        position: fixed;
        height: 100vh;
        z-index: 100;
        box-shadow: var(--shadow-md);
        border-right: 1px solid var(--medium-gray);
        transition: transform 0.3s ease;
    }

    .sidebar-header {
        margin-bottom: 2.5rem;
        padding-bottom: 1.5rem;
        border-bottom: 1px solid var(--medium-gray);
    }

    .sidebar-header h2 {
        color: var(--primary);
        font-size: 1.5rem;
        font-weight: 700;
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-header h2 i {
        font-size: 1.75rem;
    }

    .sidebar-nav {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .nav-item {
        display: flex;
        align-items: center;
        gap: 1rem;
        color: var(--dark-gray);
        padding: 0.875rem 1.25rem;
        border-radius: var(--border-radius);
        text-decoration: none;
        font-weight: 500;
        transition: var(--transition);
    }

    .nav-item:hover {
        background-color: var(--primary-light);
        color: var(--primary);
        transform: translateX(5px);
    }

    .nav-item.active {
        background-color: var(--primary-light);
        color: var(--primary);
        font-weight: 600;
    }

    .nav-item i {
        width: 20px;
        text-align: center;
    }

    .sidebar-footer {
        margin-top: auto;
        padding-top: 1.5rem;
        border-top: 1px solid var(--medium-gray);
    }

    /* Main Content */
    .main-content {
        flex: 1;
        margin-left: 280px;
        padding: 2.5rem;
        transition: margin-left 0.3s ease;
    }

    .page-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        margin-bottom: 2rem;
    }

    .page-title {
        font-size: 1.75rem;
        font-weight: 700;
        color: var(--dark);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .page-title i {
        color: var(--primary);
    }

    .page-description {
        color: var(--dark-gray);
        margin-top: 0.5rem;
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-weight: 600;
    }

    /* Support Cards */
    .support-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 1.5rem;
        margin-top: 2rem;
    }

    .support-card {
        background: var(--light);
        border-radius: var(--border-radius);
        box-shadow: var(--shadow-sm);
        border: 1px solid var(--medium-gray);
        overflow: hidden;
        transition: var(--transition);
    }

    .support-card:hover {
        transform: translateY(-5px);
        box-shadow: var(--shadow-md);
    }

    .card-header {
        padding: 1.5rem;
        background-color: var(--light-gray);
        border-bottom: 1px solid var(--medium-gray);
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .card-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        background-color: var(--primary-light);
        display: flex;
        align-items: center;
        justify-content: center;
        color: var(--primary);
        font-size: 1.25rem;
    }

    .card-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--dark);
    }

    .card-body {
        padding: 1.5rem;
    }

    .support-list {
        list-style: none;
    }

    .support-list li {
        padding: 1rem 0;
        border-bottom: 1px solid var(--medium-gray);
        display: flex;
        gap: 1rem;
    }

    .support-list li:last-child {
        border-bottom: none;
    }

    .list-icon {
        color: var(--primary);
        font-size: 1.1rem;
        margin-top: 3px;
    }

    .list-content {
        flex: 1;
    }

    .list-title {
        font-weight: 600;
        margin-bottom: 0.25rem;
        color: var(--dark);
    }

    .list-description {
        color: var(--dark-gray);
        font-size: 0.9rem;
    }

    .contact-link {
        color: var(--primary);
        text-decoration: none;
        transition: var(--transition);
    }

    .contact-link:hover {
        text-decoration: underline;
    }

    /* Mobile Toggle Button */
    .mobile-toggle {
        display: none;
        position: fixed;
        top: 1rem;
        left: 1rem;
        z-index: 1000;
        background: var(--primary);
        color: var(--light);
        width: 40px;
        height: 40px;
        border-radius: 50%;
        border: none;
        cursor: pointer;
        box-shadow: var(--shadow-md);
        justify-content: center;
        align-items: center;
    }

    /* Responsive Design */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
            padding: 1.5rem;
            padding-top: 5rem;
        }

        .mobile-toggle {
            display: flex;
        }
    }

    @media (max-width: 768px) {
        .page-header {
            flex-direction: column;
            align-items: flex-start;
            gap: 1rem;
        }

        .user-profile {
            width: 100%;
            justify-content: flex-end;
        }

        .support-grid {
            grid-template-columns: 1fr;
        }
    }

    @media (max-width: 576px) {
        .main-content {
            padding: 1.25rem;
            padding-top: 5rem;
        }

        .page-title {
            font-size: 1.5rem;
        }
    }
    </style>
</head>
<body>
<div class="dashboard-container">
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" id="mobileToggle">
        <i class="fas fa-bars"></i>
    </button>

    <!-- Sidebar -->
    <aside class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <h2><i class="fas fa-gavel"></i> CompCure</h2>
        </div>
        
        <nav class="sidebar-nav">
            <a href="dashboard.php" class="nav-item">
                <i class="fas fa-chart-pie"></i>
                Dashboard
            </a>
            <a href="register_complaint.php" class="nav-item">
                <i class="fas fa-edit"></i>
                New Complaint
            </a>
            <a href="complaint_table.php" class="nav-item">
                <i class="fas fa-list"></i>
                My Complaints
            </a>
            <a href="support.php" class="nav-item active">
                <i class="fas fa-headset"></i>
                Support
            </a>
            <a href="feedback_form.php" class="nav-item">
                <i class="fas fa-comment-alt"></i>
                Feedback
            </a>
            <a href="help.php" class="nav-item">
                <i class="fas fa-question-circle"></i>
                Help Center
            </a>
            
            <div class="sidebar-footer">
                <a href="/final/Login.php" class="nav-item">
                    <i class="fas fa-sign-out-alt"></i>
                    Logout
                </a>
            </div>
        </nav>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <div class="page-header">
            <div>
                <h1 class="page-title">
                    <i class="fas fa-headset"></i>
                    Support Center
                </h1>
                <p class="page-description">We're here to help you 24/7 with any issues or questions</p>
            </div>
            <div class="user-profile">

            </div>
        </div>

        <div class="support-grid">
            <!-- Contact Support Card -->
            <div class="support-card">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-phone-alt"></i>
                    </div>
                    <h3 class="card-title">Contact Support</h3>
                </div>
                <div class="card-body">
                    <ul class="support-list">
                        <li>
                            <i class="fas fa-envelope list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Email Support</div>
                                <div class="list-description">
                                    <a href="mailto:support@complaintsystem.com" class="contact-link">support@complaintsystem.com</a>
                                </div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-phone list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Phone Support</div>
                                <div class="list-description">+91 7972588319</div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-clock list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Support Hours</div>
                                <div class="list-description">24/7 Availability</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Help Guides Card -->
            <div class="support-card">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-book-open"></i>
                    </div>
                    <h3 class="card-title">Help Guides</h3>
                </div>
                <div class="card-body">
                    <ul class="support-list">
                        <li>
                            <i class="fas fa-file-alt list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">File a Complaint</div>
                                <div class="list-description">Step-by-step guide to register new complaints</div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-search list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Track Status</div>
                                <div class="list-description">How to check your complaint progress</div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-file-download list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Download Forms</div>
                                <div class="list-description">Access required documents and templates</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>

            <!-- Emergency Support Card -->
            <div class="support-card">
                <div class="card-header">
                    <div class="card-icon">
                        <i class="fas fa-exclamation-triangle"></i>
                    </div>
                    <h3 class="card-title">Emergency Help</h3>
                </div>
                <div class="card-body">
                    <ul class="support-list">
                        <li>
                            <i class="fas fa-comment-medical list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Live Chat</div>
                                <div class="list-description">Instant contact with support agents</div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-headset list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Callback Service</div>
                                <div class="list-description">Request immediate phone support</div>
                            </div>
                        </li>
                        <li>
                            <i class="fas fa-ambulance list-icon"></i>
                            <div class="list-content">
                                <div class="list-title">Urgent Escalation</div>
                                <div class="list-description">Critical issue escalation process</div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </main>
</div>

<script>
    // Mobile Toggle
    const mobileToggle = document.getElementById('mobileToggle');
    const sidebar = document.getElementById('sidebar');

    mobileToggle.addEventListener('click', () => {
        sidebar.classList.toggle('active');
    });

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (e) => {
        if(window.innerWidth <= 1024 && 
           !sidebar.contains(e.target) && 
           e.target !== mobileToggle) {
            sidebar.classList.remove('active');
        }
    });

    // Auto-close sidebar when resizing to desktop
    window.addEventListener('resize', () => {
        if (window.innerWidth > 1024) {
            sidebar.classList.remove('active');
        }
    });
</script>
</body>
</html>