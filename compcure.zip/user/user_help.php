<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

// Check if help_request_id is provided in the URL
if (!isset($_GET['help_request_id'])) {
    die("Error: Help request ID is missing.");
}

$user_id = $_SESSION['user_id'];
$help_request_id = $_GET['help_request_id']; // Get the help request ID from the URL

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle message submission via AJAX
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    $message = $conn->real_escape_string($_POST['message']);
    $sql = "INSERT INTO help_messages (help_request_id, sender_type, message) VALUES (?, 'User', ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("is", $help_request_id, $message);
    $stmt->execute();
    $stmt->close();
    exit(); // Stop further execution for AJAX requests
}

// Fetch messages
$sql = "SELECT sender_type, message, created_at FROM help_messages WHERE help_request_id = ? ORDER BY created_at ASC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $help_request_id);
$stmt->execute();
$result = $stmt->get_result();
$messages = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$conn->close();

// Return messages as JSON
echo json_encode($messages);
?>