<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: /final/Login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch complaint details
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $sql = "SELECT * FROM complaints WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $complaint = $result->fetch_assoc();
    $stmt->close();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_id'])) {
    $update_id = $_POST['update_id'];
    $full_name = $_POST['full_name'];
    $title_of_complaint = $_POST['title_of_complaint'];
    $state = $_POST['state'];
    $city = $_POST['city'];
    $details_of_complaint = $_POST['details_of_complaint'];

    $sql = "UPDATE complaints SET full_name = ?, title_of_complaint = ?, state = ?, city = ?, details_of_complaint = ? WHERE id = ? AND user_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssssi", $full_name, $title_of_complaint, $state, $city, $details_of_complaint, $update_id, $user_id);
    if ($stmt->execute()) {
        header("Location: complaint_table.php");
        exit();
    } else {
        echo "Error updating record: " . $conn->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Complaint</title>
</head>
<body>
    <h1>Update Complaint</h1>
    <form method="POST" action="edit_complaint.php">
        <input type="hidden" name="update_id" value="<?php echo htmlspecialchars($complaint['id']); ?>">
        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" value="<?php echo htmlspecialchars($complaint['full_name']); ?>" required><br>
        <label for="title_of_complaint">Title of Complaint:</label>
        <input type="text" id="title_of_complaint" name="title_of_complaint" value="<?php echo htmlspecialchars($complaint['title_of_complaint']); ?>" required><br>
        <label for="state">State:</label>
        <input type="text" id="state" name="state" value="<?php echo htmlspecialchars($complaint['state']); ?>" required><br>
        <label for="city">City:</label>
        <input type="text" id="city" name="city" value="<?php echo htmlspecialchars($complaint['city']); ?>" required><br>
        <label for="details_of_complaint">Details of Complaint:</label>
        <textarea id="details_of_complaint" name="details_of_complaint" required><?php echo htmlspecialchars($complaint['details_of_complaint']); ?></textarea><br>
        <button type="submit">Update Complaint</button>
    </form>
</body>
</html>