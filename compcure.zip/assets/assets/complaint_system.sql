-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 18, 2025 at 08:55 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `complaint_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_logins`
--

CREATE TABLE `admin_logins` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_logins`
--

INSERT INTO `admin_logins` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(6) UNSIGNED NOT NULL,
  `title_of_complaint` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `details_of_complaint` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Yet to Proceed',
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `full_name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `file_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `title_of_complaint`, `state`, `city`, `details_of_complaint`, `file`, `status`, `reg_date`, `full_name`, `user_id`, `file_path`) VALUES
(34, 's', 's', 's', 's\r\n', '', 'Closed', '2025-03-14 15:14:42', 's', 2, NULL),
(50, 't', 'tt', 't', 't\r\n', '1.jpg', 'In Progress', '2025-03-17 13:07:52', 't', 9, NULL),
(53, 'e', 'e', 'e', 'e\r\n', 'WIN_20250307_11_17_26_Pro.jpg', 'Completed', '2025-03-16 15:25:54', 'e', 2, NULL),
(54, 's', 'g', 'g', 'h\r\n', 'Internet of Things.pdf', 'Seen', '2025-03-17 13:07:37', 'eeee', 2, NULL),
(55, 'a', 'a', 'a', 'a\r\n', '2.webp', 'Completed', '2025-03-17 07:19:34', 'asd', 9, NULL),
(57, 'w', 'w', 'w', 'w\r\n', '', 'In Progress', '2025-03-17 14:27:37', 'ws', 2, NULL),
(58, 'q', 'w', 'd', 'f', 'R-removebg-preview.png', 'In Progress', '2025-03-18 04:22:20', 'e', 2, NULL),
(59, 's', 's', 's', 's', '', 'New', '2025-03-17 13:22:35', 's', 2, NULL),
(60, 'w', 'w', 'w', 'w\r\nw\r\n', '', 'New', '2025-03-17 13:22:41', 'w', 2, NULL),
(61, 'l', 'l', 'l', 'l\r\n', 'Internet of Things (1).pdf', 'New', '2025-03-17 13:58:37', 'l', 2, NULL),
(62, 'r', 'r', 'r', 'rr\r\n', '', 'New', '2025-03-17 14:08:52', 'r', 2, NULL),
(63, 'w', 'w', 'w', 'ww\r\n', '', 'New', '2025-03-17 14:08:58', 'w', 2, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `username` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL,
  `profile_image` varchar(255) DEFAULT 'default_profile.png'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `reg_date`, `username`, `contact`, `profile_image`) VALUES
(2, 'shri@gmail.com', '$2y$10$ME2kLUIahBhi.F.DbG1R9.D57eqTD7ht6OS9DTs6iz1QSDfuY80US', '2025-03-17 11:54:43', 'Shrinivas', '9923690832', 'uploads/12.jpg'),
(9, 'omkar@gmail.com', '$2y$10$mCmbZ8.jrBtIVGnB7KgKEuckmJfTKAan3DfS0wuwm7kw5uYtd9IFi', '2025-03-16 15:23:02', 'omkar', '888888888888', 'uploads/WIN_20250307_11_17_26_Pro.jpg');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_logins`
--
ALTER TABLE `admin_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_logins`
--
ALTER TABLE `admin_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=64;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
