<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CompCure - Complaint Management System</title>
    <style>
        :root {
            --primary: #4361ee;
            --accent: #f72585;
            --dark: #212529;
            --light: #f8f9fa;
        }

        footer {
            background-color: var(--dark);
            color: white;
            padding: 40px 0 20px;
            text-align: center;
            position: relative;
            overflow: hidden;
            font-family: 'Poppins', sans-serif;
        }

        .footer-content {
            max-width: 1200px;
            margin: 0 auto;
            padding: 0 20px;
        }

        .footer-logo {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 20px;
            display: inline-block;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            position: relative;
        }

        .footer-logo::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 3px;
            background: linear-gradient(90deg, var(--primary), var(--accent));
            border-radius: 3px;
        }

        .footer-icons {
            display: flex;
            justify-content: center;
            gap: 20px;
            margin-bottom: 25px;
        }

        .footer-icons a {
            color: rgba(255, 255, 255, 0.7);
            font-size: 20px;
            transition: all 0.3s ease;
            display: inline-block;
        }

        .footer-icons a:hover {
            color: white;
            transform: translateY(-5px) scale(1.2);
        }

        .footer-copyright {
            color: rgba(255, 255, 255, 0.5);
            font-size: 14px;
            margin-top: 20px;
        }

        /* Pulse animation for logo */
        @keyframes pulse {
            0% { transform: scale(1); }
            50% { transform: scale(1.05); }
            100% { transform: scale(1); }
        }

        .footer-logo:hover {
            animation: pulse 1.5s infinite;
        }

        /* Floating animation for icons */
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-5px); }
            100% { transform: translateY(0px); }
        }

        .footer-icons a:nth-child(1) { animation: float 3s ease-in-out infinite; }
        .footer-icons a:nth-child(2) { animation: float 3s ease-in-out infinite 0.5s; }
        .footer-icons a:nth-child(3) { animation: float 3s ease-in-out infinite 1s; }
        .footer-icons a:nth-child(4) { animation: float 3s ease-in-out infinite 1.5s; }
        .footer-icons a:nth-child(5) { animation: float 3s ease-in-out infinite 2s; }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .footer-logo {
                font-size: 24px;
            }
            .footer-icons a {
                font-size: 18px;
            }
        }
    </style>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600;700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Your page content here -->

    <footer>
        <div class="footer-content">
            <div class="footer-logo">CompCure</div>
            <div class="footer-icons">
                <a href="www.facebook.com" aria-label="Facebook"><i class="fab fa-facebook-f"></i></a>
                <a href="#" aria-label="Twitter"><i class="fab fa-twitter"></i></a>
                <a href="#" aria-label="LinkedIn"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://www.instagram.com/compcure2026?igsh=MzRlODBiNWFlZA==" aria-label="Instagram"><i class="fab fa-instagram"></i></a>
                <a href="#" aria-label="GitHub"><i class="fab fa-github"></i></a>
            </div>
            <div class="footer-copyright">
                &copy; <span id="current-year"></span> CompCure. All rights reserved.
            </div>
        </div>
    </footer>

    <script>
        // Set current year automatically
        document.getElementById('current-year').textContent = new Date().getFullYear();

        // Add hover effect with JavaScript for better control
        const icons = document.querySelectorAll('.footer-icons a');
        icons.forEach(icon => {
            icon.addEventListener('mouseenter', () => {
                icon.style.animation = 'none';
                setTimeout(() => {
                    icon.style.animation = '';
                }, 100);
            });
        });
    </script>
</body>
</html>