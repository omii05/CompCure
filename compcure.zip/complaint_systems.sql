-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 11, 2025 at 09:40 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `complaint_system`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_logins`
--

CREATE TABLE `admin_logins` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_logins`
--

INSERT INTO `admin_logins` (`id`, `email`, `password`) VALUES
(1, 'admin@gmail.com', '1234');

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

CREATE TABLE `complaints` (
  `id` int(6) UNSIGNED NOT NULL,
  `title_of_complaint` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `details_of_complaint` text NOT NULL,
  `file` varchar(255) DEFAULT NULL,
  `status` varchar(50) DEFAULT 'Yet to Proceed',
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `full_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `complaints`
--

INSERT INTO `complaints` (`id`, `title_of_complaint`, `state`, `city`, `details_of_complaint`, `file`, `status`, `reg_date`, `full_name`) VALUES
(18, 's', 's', 's', 's\r\n', '', 'New', '2025-03-11 02:38:45', 'shri');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(6) UNSIGNED NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reg_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `username` varchar(50) NOT NULL,
  `contact` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `password`, `reg_date`, `username`, `contact`) VALUES
(1, '', '$2y$10$9zaWM8cMLJ1IrD6VfzwRLu6qQJz0voBc.K3BzQ17IURNTQsTUzzMe', '2025-03-08 05:48:14', '', ''),
(2, 'shri@gmail.com', '$2y$10$l8NPDvHu49IB2zbumrRdgOGsN2bNPiGKAdaF8iaaUz1UClO6/793e', '2025-03-08 05:49:49', '', ''),
(3, 'shrinivas3@gmail.com', '$2y$10$uoffkQ6NEYwjIVjbE3i05.KVr8No9S20wHDfbjNsNJwizbi58i5F.', '2025-03-08 05:57:51', 'shrinivas', '9923690832'),
(4, 'user@gmail.com', '$2y$10$E5Inuv1AHLw4w29Z0CuWE.K0WpJOelJ8mQN4S9ISXy/yvrvbEbbaK', '2025-03-10 16:04:06', 'user', '992345678'),
(5, 'user@gmail.com', '$2y$10$fjWKUAjVWp2io.ZSXWtq0OSkTkOz8o55EBWzG3e6vF35fT0qnjrdq', '2025-03-11 07:43:46', 'user ', '7998588319'),
(6, 'onkar@gmail.com', '$2y$10$7GFfOwihNOlxYLeYNIZIz.uv/XPKBfQ9UMhc/FI3osX0O/KX6oku.', '2025-03-11 08:31:12', 'onkar', '9922345677');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_logins`
--
ALTER TABLE `admin_logins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `complaints`
--
ALTER TABLE `complaints`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_logins`
--
ALTER TABLE `admin_logins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `complaints`
--
ALTER TABLE `complaints`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(6) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
