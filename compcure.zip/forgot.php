<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$message = "";
$message_type = ""; // success or error

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    if ($new_password === $confirm_password) {
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        if (!empty($email)) {
            $sql = "SELECT id FROM users WHERE email = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $email);
        } elseif (!empty($phone)) {
            $sql = "SELECT id FROM users WHERE contact = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $phone);
        } else {
            $message = "Please provide either an email or phone number";
            $message_type = "error";
        }

        if (!empty($email) || !empty($phone)) {
            $stmt->execute();
            $stmt->store_result();
            
            if ($stmt->num_rows > 0) {
                if (!empty($email)) {
                    $update_sql = "UPDATE users SET password = ? WHERE email = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("ss", $hashed_password, $email);
                } else {
                    $update_sql = "UPDATE users SET password = ? WHERE contact = ?";
                    $update_stmt = $conn->prepare($update_sql);
                    $update_stmt->bind_param("ss", $hashed_password, $phone);
                }

                if ($update_stmt->execute()) {
                    $message = "Password reset successfully! Redirecting to login...";
                    $message_type = "success";
                    $_SESSION['reset_success'] = true;
                    header("Refresh: 3; url=login.php");
                } else {
                    $message = "Error resetting password";
                    $message_type = "error";
                }
                $update_stmt->close();
            } else {
                $message = "Account not found with provided details";
                $message_type = "error";
            }
            $stmt->close();
        }
    } else {
        $message = "Passwords do not match";
        $message_type = "error";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password - Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #4361ee;
            --dark-blue: #3f37c9;
            --light-blue: #4895ef;
            --white: #ffffff;
            --light-gray: #f8f9fa;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-color: #212529;
            --success: #4cc9f0;
            --error: #ef233c;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Poppins', sans-serif;
            background-image: url('https://images.unsplash.com/photo-1551434678-e076c223a692?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(255, 255, 255, 0.9);
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            padding: 40px;
        }

        .illustration {
            width: 500px;
            height: auto;
            margin-right: 60px;
            animation: float 6s ease-in-out infinite;
        }

        @keyframes float {
            0%, 100% { transform: translateY(0); }
            50% { transform: translateY(-20px); }
        }

        .forgot-container {
            background: rgba(255, 255, 255, 0.95);
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 450px;
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            animation: fadeIn 0.6s ease;
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .forgot-container h2 {
            color: var(--primary-blue);
            text-align: center;
            margin-bottom: 30px;
            font-size: 1.8rem;
            font-weight: 700;
            position: relative;
        }

        .forgot-container h2::after {
            content: '';
            position: absolute;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, var(--primary-blue), var(--light-blue));
            border-radius: 2px;
        }

        /* Message Styles */
        .message {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            animation: fadeIn 0.5s ease;
        }

        .message.success {
            background-color: rgba(76, 201, 240, 0.15);
            color: var(--success);
            border-left: 4px solid var(--success);
        }

        .message.error {
            background-color: rgba(239, 35, 60, 0.15);
            color: var(--error);
            border-left: 4px solid var(--error);
        }

        .message i {
            font-size: 1.2rem;
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 25px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 500;
            color: var(--text-color);
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 14px 20px 14px 45px;
            border: 1px solid var(--medium-gray);
            border-radius: 8px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.3s ease;
            background-color: rgba(248, 249, 250, 0.8);
        }

        .form-group input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1);
            outline: none;
            background-color: var(--white);
        }

        .form-group i {
            position: absolute;
            left: 15px;
            bottom: 14px;
            color: var(--dark-gray);
            font-size: 1.2rem;
        }

        /* Buttons */
        .reset-button {
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            color: var(--white);
            border: none;
            padding: 15px;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
            width: 100%;
            margin-top: 10px;
            position: relative;
            overflow: hidden;
        }

        .reset-button:hover {
            background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.4);
        }

        .reset-button.loading {
            pointer-events: none;
        }

        .reset-button.loading::after {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            animation: buttonLoading 1.5s linear infinite;
        }

        @keyframes buttonLoading {
            0% { transform: translateX(-100%); }
            100% { transform: translateX(100%); }
        }

        .button-text {
            transition: all 0.3s ease;
            position: relative;
        }

        .back-button {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            color: var(--primary-blue);
            text-decoration: none;
            font-weight: 500;
            margin-top: 20px;
            transition: all 0.3s ease;
            position: relative;
        }

        .back-button::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-blue);
            transition: width 0.3s ease;
        }

        .back-button:hover {
            color: var(--dark-blue);
        }

        .back-button:hover::after {
            width: 100%;
        }

        /* Responsive Design */
        @media (max-width: 1024px) {
            .illustration {
                width: 400px;
                margin-right: 40px;
            }
        }

        @media (max-width: 768px) {
            .container {
                flex-direction: column;
                padding: 30px;
            }
            
            .illustration {
                width: 300px;
                margin-right: 0;
                margin-bottom: 40px;
            }
            
            .forgot-container {
                padding: 30px;
            }
        }

        @media (max-width: 480px) {
            .container {
                padding: 20px;
            }
            
            .forgot-container {
                padding: 25px 20px;
            }
            
            .form-group input {
                padding: 12px 20px 12px 40px;
            }
        }
    </style>
</head>
<body>
    
    <div class="container">
        <img src="/final/assets/reset.png" alt="Password Reset Illustration" class="illustration">
        
        <div class="forgot-container">
            <h2><i class="fas fa-key"></i> Reset Password</h2>
            
            <?php if (!empty($message)): ?>
            <div class="message <?php echo $message_type; ?>">
                <i class="fas <?php echo $message_type == 'success' ? 'fa-check-circle' : 'fa-exclamation-circle'; ?>"></i>
                <span><?php echo $message; ?></span>
            </div>
            <?php endif; ?>
            
            <form id="resetForm" action="forgot.php" method="POST">
                <div class="form-group">
                    <label for="email">Email</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="email" name="email" placeholder="your@email.com">
                </div>
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <i class="fas fa-phone"></i>
                    <input type="text" id="phone" name="phone" placeholder="Enter phone number">
                </div>
                <div class="form-group">
                    <label for="new_password">New Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" id="new_password" name="new_password" required placeholder="••••••••">
                </div>
                <div class="form-group">
                    <label for="confirm_password">Confirm Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" id="confirm_password" name="confirm_password" required placeholder="••••••••">
                </div>
                <button type="submit" class="reset-button" id="resetButton">
                    <span class="button-text">Reset Password</span>
                </button>
            </form>
            <a href="login.php" class="back-button"><i class="fas fa-arrow-left"></i> Back to Login</a>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const resetForm = document.getElementById('resetForm');
            const resetButton = document.getElementById('resetButton');
            const buttonText = document.querySelector('.button-text');
            
            resetForm.addEventListener('submit', function(e) {
                e.preventDefault();
                
                // Show loading state
                resetButton.classList.add('loading');
                buttonText.textContent = 'Processing...';
                
                // Submit the form after 3 seconds
                setTimeout(() => {
                    this.submit();
                }, 3000);
            });
            
            // Animate form elements
            const formGroups = document.querySelectorAll('.form-group');
            formGroups.forEach((group, index) => {
                group.style.opacity = '0';
                group.style.transform = 'translateY(20px)';
                group.style.transition = `all 0.5s ease ${index * 0.1}s`;
                
                setTimeout(() => {
                    group.style.opacity = '1';
                    group.style.transform = 'translateY(0)';
                }, 100);
            });
        });
    </script>
</body>
</html>