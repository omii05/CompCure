<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize the statement variable
$stmt = null;

// Check if the id parameter is set
if (isset($_GET['id'])) {
    $id = intval($_GET['id']); // Get the complaint ID

    // Prepare the SQL statement
    $sql = "SELECT file, file_type FROM complaints WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if ($stmt) {
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $stmt->store_result();
        $stmt->bind_result($fileContent, $fileType);

        if ($stmt->num_rows > 0) {
            $stmt->fetch();

            // Set the appropriate content type
            header('Content-Type: ' . $fileType);

            // Output the file content
            echo $fileContent;
            exit;
        } else {
            echo "File not found.";
        }
    } else {
        echo "Failed to prepare the SQL statement.";
    }
} else {
    echo "No file specified.";
}

// Close the statement if it was created
if ($stmt) {
    $stmt->close();
}

// Close the database connection
$conn->close();
?>