<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch count of received complaints
$sql_received_complaints = "SELECT COUNT(*) as count FROM complaints";
$result_received_complaints = $conn->query($sql_received_complaints);
$received_complaints_count = $result_received_complaints->fetch_assoc()['count'];

// Fetch count of registered users
$sql_registered_users = "SELECT COUNT(*) as count FROM users";
$result_registered_users = $conn->query($sql_registered_users);
$registered_users_count = $result_registered_users->fetch_assoc()['count'];

$sql_completed_complaints = "SELECT COUNT(*) as count FROM complaints WHERE status = 'Completed'";
$result_completed_complaints = $conn->query($sql_completed_complaints);
$completed_complaints_count = $result_completed_complaints->fetch_assoc()['count'];

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Analytics</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4f46e5;
        --primary-light: #6366f1;
        --primary-dark: #4338ca;
        --success: #10b981;
        --success-dark: #059669;
        --warning: #f59e0b;
        --warning-dark: #d97706;
        --danger: #ef4444;
        --danger-dark: #dc2626;
        --info: #3b82f6;
        --info-dark: #2563eb;
        --dark: #1e293b;
        --light: #f8fafc;
        --gray: #94a3b8;
        --gray-dark: #64748b;
        --sidebar-width: 260px;
        --sidebar-collapsed-width: 80px;
        --header-height: 70px;
        --transition-speed: 0.3s;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    body {
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background-color: #f1f5f9;
        color: var(--dark);
        line-height: 1.6;
        overflow-x: hidden;
    }

    .app-container {
        display: flex;
        min-height: 100vh;
    }

    /* Sidebar Styles */
    .sidebar {
        width: var(--sidebar-width);
        background: white;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        transition: all var(--transition-speed) ease;
        position: fixed;
        height: 100vh;
        z-index: 1000;
        overflow-y: auto;
    }

    .sidebar-collapsed {
        width: var(--sidebar-collapsed-width);
    }

    .sidebar-header {
        padding: 1.5rem 1rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sidebar-logo {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-logo i {
        font-size: 1.5rem;
    }

    .sidebar-menu {
        padding: 1rem 0;
    }

    .sidebar-menu h3 {
        padding: 0.5rem 1rem;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--gray);
        margin-bottom: 0.5rem;
    }

    .sidebar-link {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        margin: 0 0.5rem;
        color: var(--gray-dark);
        text-decoration: none;
        border-radius: 0.375rem;
        transition: all 0.2s ease;
    }

    .sidebar-link:hover {
        background-color: #f1f5f9;
        color: var(--primary);
    }

    .sidebar-link.active {
        background-color: #e0e7ff;
        color: var(--primary);
        font-weight: 500;
    }

    .sidebar-link i {
        margin-right: 0.75rem;
        width: 24px;
        text-align: center;
    }

    .sidebar-link span {
        white-space: nowrap;
        transition: opacity var(--transition-speed) ease;
    }

    .sidebar-collapsed .sidebar-link span {
        opacity: 0;
        width: 0;
        display: none;
    }

    .sidebar-collapsed .sidebar-menu h3 {
        opacity: 0;
        height: 0;
        padding: 0;
        margin: 0;
        overflow: hidden;
    }

    .sidebar-footer {
        margin-top: auto;
        padding: 1rem;
        border-top: 1px solid #e2e8f0;
    }

    /* Main Content Styles */
    .main-content {
        flex: 1;
        margin-left: var(--sidebar-width);
        transition: margin-left var(--transition-speed) ease;
    }

    .main-content-collapsed {
        margin-left: var(--sidebar-collapsed-width);
    }

    /* Header Styles */
    .header {
        height: var(--header-height);
        background: white;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        padding: 0 2rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 100;
    }

    .header-left {
        display: flex;
        align-items: center;
    }

    .toggle-sidebar {
        background: none;
        border: none;
        color: var(--gray-dark);
        font-size: 1.25rem;
        cursor: pointer;
        margin-right: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        transition: all 0.2s ease;
    }

    .toggle-sidebar:hover {
        background-color: #f1f5f9;
        color: var(--primary);
    }

    .header-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--dark);
        transition: opacity var(--transition-speed) ease;
    }

    .main-content-collapsed .header-title {
        opacity: 0;
        width: 0;
    }

    .header-actions {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background-color: var(--primary-light);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
    }

    .user-name {
        font-weight: 500;
        transition: opacity var(--transition-speed) ease;
    }

    .main-content-collapsed .user-name {
        opacity: 0;
        width: 0;
    }

    /* Content Styles */
    .content {
        padding: 2rem;
    }

    /* Dashboard Cards */
    .dashboard-cards {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 2.5rem;
        margin-bottom: 2rem;
    }

    .card {
        background: white;
        border-radius: 0.5rem;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        padding: 1.5rem;
        transition: transform 0.2s ease;
        position: relative;
        overflow: hidden;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
    }

    .card.complaints::before {
        background-color: var(--info);
    }

    .card.users::before {
        background-color: var(--success);
    }

    .card.completed::before {
        background-color: var(--primary);
    }

    .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1rem;
    }

    .card-title {
        font-size: 0.875rem;
        color: var(--gray-dark);
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .card-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }

    .card-icon.complaints {
        background-color: var(--info);
    }

    .card-icon.users {
        background-color: var(--success);
    }

    .card-icon.completed {
        background-color: var(--primary);
    }

    .card-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 0.5rem;
    }

    .card-footer {
        display: flex;
        align-items: center;
        font-size: 0.75rem;
        color: var(--gray);
        margin-top: 1rem;
    }

    .card-footer i {
        margin-right: 0.5rem;
    }

    /* Responsive Styles */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
        }

        .toggle-sidebar {
            display: flex;
        }
    }

    @media (max-width: 768px) {
        .dashboard-cards {
            grid-template-columns: 1fr;
        }

        .header {
            padding: 0 1rem;
        }

        .content {
            padding: 1rem;
        }
    }

    @media (max-width: 576px) {
        .header-title {
            display: none;
        }
    }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-shield-alt"></i>
                    <span class="logo-text"></span>
                </div>
            </div>
            <div class="sidebar-menu">
                <h3>Main</h3>
                <a href="dashboard.php" class="sidebar-link active">
                    <i class="fas fa-chart-line"></i>
                    <span>Dashboard</span>
                </a>
                <a href="admin_dashboard.php" class="sidebar-link">
                    <i class="fas fa-tasks"></i>
                    <span>Complaints</span>
                </a>
                <a href="total_registered.php" class="sidebar-link">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="complaint_history.php" class="sidebar-link">
                    <i class="fas fa-history"></i>
                    <span>History</span>
                </a>
                <a href="admin_help.php" class="sidebar-link">
                    <i class="fas fa-question-circle"></i>
                    <span>Help</span>
                </a>
            </div>
            <div class="sidebar-footer">
                <a href="/final/home.php" class="sidebar-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Dashboard Overview</h1>
                </div>
                <div class="header-actions">
                    <div class="user-profile">
                        <div class="user-avatar">A</div>
                        <span class="user-name">Admin</span>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <div class="content">
                <!-- Dashboard Cards -->
                <div class="dashboard-cards">
                    <div class="card complaints">
                        <div class="card-header">
                            <h3 class="card-title">Received Complaints</h3>
                            <div class="card-icon complaints">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $received_complaints_count; ?></div>
                        <div class="card-footer">
                            <i class="fas fa-calendar-alt"></i>
                            <span>All time</span>
                        </div>
                    </div>
                    <div class="card users">
                        <div class="card-header">
                            <h3 class="card-title">Registered Users</h3>
                            <div class="card-icon users">
                                <i class="fas fa-users"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $registered_users_count; ?></div>
                        <div class="card-footer">
                            <i class="fas fa-calendar-alt"></i>
                            <span>All time</span>
                        </div>
                    </div>
                    <div class="card completed">
                        <div class="card-header">
                            <h3 class="card-title">Completed Complaints</h3>
                            <div class="card-icon completed">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $completed_complaints_count; ?></div>
                        <div class="card-footer">
                            <i class="fas fa-calendar-alt"></i>
                            <span>All time</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
    // Toggle sidebar on all screen sizes
    const toggleSidebar = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    let isCollapsed = false;

    // Check if we're on mobile
    function isMobile() {
        return window.innerWidth <= 1024;
    }

    // Toggle sidebar function
    function toggleSidebarState() {
        if (isMobile()) {
            // On mobile, just toggle the active class
            sidebar.classList.toggle('active');
        } else {
            // On desktop, toggle between collapsed and expanded states
            isCollapsed = !isCollapsed;
            sidebar.classList.toggle('sidebar-collapsed');
            mainContent.classList.toggle('main-content-collapsed');
            
            // Change icon based on state
            const icon = toggleSidebar.querySelector('i');
            icon.className = isCollapsed ? 'fas fa-chevron-right' : 'fas fa-bars';
        }
    }

    // Initialize sidebar state
    function initSidebar() {
        if (!isMobile()) {
            // On desktop, start with expanded sidebar
            sidebar.classList.remove('active');
            sidebar.classList.remove('sidebar-collapsed');
            mainContent.classList.remove('main-content-collapsed');
            toggleSidebar.querySelector('i').className = 'fas fa-bars';
        } else {
            // On mobile, start with hidden sidebar
            sidebar.classList.remove('sidebar-collapsed');
            mainContent.classList.remove('main-content-collapsed');
            sidebar.classList.remove('active');
        }
    }

    // Event listeners
    toggleSidebar.addEventListener('click', toggleSidebarState);

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (event) => {
        if (isMobile() && 
            !sidebar.contains(event.target) && 
            !toggleSidebar.contains(event.target)) {
            sidebar.classList.remove('active');
        }
    });

    // Handle window resize
    window.addEventListener('resize', () => {
        initSidebar();
    });

    // Initialize on load
    document.addEventListener('DOMContentLoaded', initSidebar);
    </script>
</body>
</html>