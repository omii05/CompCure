<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Portal | CompCure</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-blue: #4361ee;
            --dark-blue: #3f37c9;
            --light-blue: #4895ef;
            --white: #ffffff;
            --light-gray: #f8f9fa;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-color: #212529;
            --error: #ef233c;
            --success: #4cc9f0;
        }

        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background: 
                linear-gradient(rgba(255, 255, 255, 0.92), rgba(255, 255, 255, 0.95)),
                url('/final/assets/bk1.jpg') no-repeat center center fixed;
            background-size: cover;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            color: var(--text-color);
        }

        .back-button {
            position: absolute;
            top: 30px;
            left: 30px;
            background: rgba(67, 97, 238, 0.1);
            color: var(--primary-blue);
            border: none;
            padding: 10px 20px;
            border-radius: 50px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .back-button:hover {
            background: rgba(67, 97, 238, 0.2);
            transform: translateY(-2px);
        }

        .login-container {
            background-color: var(--white);
            padding: 50px 40px;
            border-radius: 16px;
            box-shadow: 0 15px 35px rgba(0, 0, 0, 0.08);
            width: 100%;
            max-width: 420px;
            position: relative;
            overflow: hidden;
            transform: translateY(0);
            opacity: 1;
            transition: all 0.5s ease;
        }

        .login-container.loading {
            transform: translateY(-10px);
            opacity: 0.8;
            filter: blur(1px);
        }

        .login-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 5px;
            background: linear-gradient(90deg, var(--primary-blue), var(--light-blue));
        }

        .logo {
            text-align: center;
            margin-bottom: 25px;
        }

        .logo i {
            font-size: 64px;
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            margin-bottom: 10px;
        }

        .login-header {
            text-align: center;
            margin-bottom: 30px;
        }

        .login-header h2 {
            color: var(--primary-blue);
            margin: 0 0 10px 0;
            font-size: 1.8rem;
            font-weight: 700;
        }

        .login-header p {
            color: var(--dark-gray);
            font-size: 0.95rem;
            margin: 0;
            font-style: italic;
        }

        .form-group {
            margin-bottom: 22px;
            position: relative;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-color);
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 12px 20px 12px 48px;
            border: 1px solid var(--medium-gray);
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.3s ease;
            background-color: var(--light-gray);
            height: 48px;
            box-sizing: border-box;
        }

        .form-group input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
            outline: none;
        }

        .form-group i {
            position: absolute;
            left: 16px;
            top: 38px;
            color: var(--dark-gray);
            font-size: 1.1rem;
        }

        .login-button {
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            color: var(--white);
            border: none;
            padding: 14px;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.2);
            width: 100%;
            margin-top: 15px;
            height: 48px;
        }

        .login-button:hover {
            background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(67, 97, 238, 0.3);
        }

        .login-button.loading {
            background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
            cursor: not-allowed;
        }

        .error-message {
            background-color: rgba(239, 35, 60, 0.08);
            color: var(--error);
            padding: 12px 16px;
            border-radius: 8px;
            margin: 20px 0 10px 0;
            display: none;
            align-items: center;
            gap: 10px;
            border-left: 3px solid var(--error);
            font-size: 0.9rem;
            animation: fadeIn 0.3s ease;
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(255, 255, 255, 0.9);
            display: none;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            transition: all 0.3s ease;
        }

        .loading-overlay.active {
            display: flex;
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 5px solid rgba(67, 97, 238, 0.2);
            border-top-color: var(--primary-blue);
            border-radius: 50%;
            animation: spin 1s linear infinite;
            margin-bottom: 20px;
        }

        .loading-text {
            font-size: 1.1rem;
            color: var(--primary-blue);
            font-weight: 500;
        }

        /* Success Animation */
        .success-animation {
            display: none;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
        }

        .success-animation i {
            font-size: 60px;
            color: var(--success);
            margin-bottom: 20px;
            animation: bounce 0.5s ease;
        }

        .success-text {
            font-size: 1.2rem;
            color: var(--text-color);
            font-weight: 500;
            margin-bottom: 10px;
        }

        .redirect-text {
            font-size: 0.9rem;
            color: var(--dark-gray);
        }

        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }

        @keyframes bounce {
            0%, 20%, 50%, 80%, 100% {transform: translateY(0);}
            40% {transform: translateY(-20px);}
            60% {transform: translateY(-10px);}
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        .password-toggle {
            position: absolute;
            right: 16px;
            top: 38px;
            cursor: pointer;
            color: var(--dark-gray);
            font-size: 1.1rem;
        }

        .security-note {
            text-align: center;
            margin-top: 30px;
            font-size: 0.85rem;
            color: var(--dark-gray);
            line-height: 1.6;
            padding: 0 10px;
        }

        .security-note i {
            color: var(--primary-blue);
            margin-right: 5px;
        }

        @media (max-width: 480px) {
            .login-container {
                padding: 40px 25px;
                margin: 20px;
            }
            
            .back-button {
                top: 15px;
                left: 15px;
            }
            
            .form-group input,
            .login-button {
                height: 44px;
            }
        }
    </style>
</head>
<body>

<button class="back-button" onclick="window.history.back()">
    <i class="fas fa-arrow-left"></i> Back
</button>

<div class="login-container" id="loginContainer">
    <div class="logo">
        <i class="fas fa-user-shield"></i>
    </div>
    
    <div class="login-header">
        <h2>Admin Portal</h2>
        <p>Secure access to system administration</p>
    </div>
    
    <form id="adminLoginForm" action="admin.php" method="POST">
        <div class="form-group">
            <label for="email">Administrator Email</label>
            <i class="fas fa-envelope"></i>
            <input type="email" id="email" name="email" placeholder="admin@compcure.com" required>
        </div>
        
        <div class="form-group">
            <label for="password">Security Credentials</label>
            <i class="fas fa-lock"></i>
            <input type="password" id="password" name="password" placeholder="••••••••" required>
            <i class="fas fa-eye password-toggle" id="togglePassword"></i>
        </div>
        
        <div id="errorDisplay" class="error-message">
            <i class="fas fa-exclamation-circle"></i>
            <span id="errorText"></span>
        </div>
        
        <button type="submit" class="login-button" id="loginBtn">
            <i class="fas fa-unlock-alt"></i> Authenticate
        </button>
    </form>
    
    <p class="security-note">
        <i class="fas fa-shield-alt"></i> All login attempts are logged and monitored. Unauthorized access is prohibited.
    </p>
</div>

<!-- Loading Overlay -->
<div class="loading-overlay" id="loadingOverlay">
    <div class="loading-spinner"></div>
    <div class="loading-text">Authenticating...</div>
</div>

<!-- Success Animation (hidden initially) -->
<div class="loading-overlay" id="successAnimation">
    <div class="success-animation">
        <i class="fas fa-check-circle"></i>
        <div class="success-text">Authentication Successful!</div>
        <div class="redirect-text">Redirecting to Admin Dashboard...</div>
    </div>
</div>

<script>
    // Password visibility toggle
    const togglePassword = document.getElementById('togglePassword');
    const passwordInput = document.getElementById('password');
    
    togglePassword.addEventListener('click', function() {
        const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
        passwordInput.setAttribute('type', type);
        this.classList.toggle('fa-eye-slash');
    });

    // Form submission handling
    document.getElementById('adminLoginForm').addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value.trim();
        const password = document.getElementById('password').value.trim();
        const errorDisplay = document.getElementById('errorDisplay');
        const errorText = document.getElementById('errorText');
        const loginBtn = document.getElementById('loginBtn');
        const loginContainer = document.getElementById('loginContainer');
        const loadingOverlay = document.getElementById('loadingOverlay');
        const successAnimation = document.getElementById('successAnimation');
        
        // Reset error state
        errorDisplay.style.display = 'none';
        loginBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Verifying...';
        loginBtn.classList.add('loading');
        loginContainer.classList.add('loading');
        
        // Show loading overlay
        loadingOverlay.classList.add('active');
        
        // Client-side validation
        if (!email || !password) {
            showError('Please fill in all fields');
            return;
        }
        
        // Simulate processing delay (in production, this would be the actual form submission)
        setTimeout(() => {
            // Hide loading overlay, show success animation
            loadingOverlay.classList.remove('active');
            successAnimation.classList.add('active');
            
            // After showing success for 2 seconds, submit the form
            setTimeout(() => {
                this.submit();
            }, 2000);
        }, 2000);
    });

    function showError(message) {
        const errorDisplay = document.getElementById('errorDisplay');
        const errorText = document.getElementById('errorText');
        const loginBtn = document.getElementById('loginBtn');
        const loginContainer = document.getElementById('loginContainer');
        const loadingOverlay = document.getElementById('loadingOverlay');
        
        errorText.textContent = message;
        errorDisplay.style.display = 'flex';
        loginBtn.innerHTML = '<i class="fas fa-unlock-alt"></i> Authenticate';
        loginBtn.classList.remove('loading');
        loginContainer.classList.remove('loading');
        loadingOverlay.classList.remove('active');
    }
</script>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "complaint_system";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the login details are correct
    $sql = "SELECT * FROM admin_logins WHERE email='$email' AND password='$password'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Redirect to admin dashboard
        echo "<script>window.location.href = '/final/admin/dashboard.php';</script>";
    } else {
        echo "<script>alert('Invalid login details');</script>";
    }

    $conn->close();
}
?>
</body>
</html>