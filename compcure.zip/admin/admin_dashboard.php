    <?php
    session_start();
    $servername = "localhost";
    $username = "root";
    $password = "";
    $dbname = "complaint_system";

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Fetch complaints from the database excluding closed complaints
    $sql = "SELECT * FROM complaints WHERE status != 'Closed'";
    $result = $conn->query($sql);

    // Fetch count of new complaints
    $sql_new_complaints = "SELECT COUNT(*) as count FROM complaints WHERE status = 'New'";
    $result_new_complaints = $conn->query($sql_new_complaints);
    if ($result_new_complaints) {
        $new_complaints_count = $result_new_complaints->fetch_assoc()['count'];
    } else {
        error_log("Error fetching new complaints count: " . $conn->error);
    }

    // Fetch count of in-progress complaints
    $sql_in_progress_complaints = "SELECT COUNT(*) as count FROM complaints WHERE status = 'In Progress'";
    $result_in_progress_complaints = $conn->query($sql_in_progress_complaints);
    $in_progress_complaints_count = $result_in_progress_complaints->fetch_assoc()['count'];

    // Fetch details of new complaints
    $sql_new_complaints_details = "SELECT * FROM complaints WHERE status = 'New'";
    $result_new_complaints_details = $conn->query($sql_new_complaints_details);

    // Check if a complaint needs to be deleted
    if (isset($_POST['delete_id'])) {
        $delete_id = $_POST['delete_id'];
        $sql_delete_complaint = "DELETE FROM complaints WHERE id = ?";
        $stmt = $conn->prepare($sql_delete_complaint);
        $stmt->bind_param("i", $delete_id);
        $stmt->execute();
        $stmt->close();
    }

    // Check if a complaint status needs to be updated
    if (isset($_POST['status']) && isset($_POST['id'])) {
        $status = $_POST['status'];
        $id = $_POST['id'];
        $sql_update_status = "UPDATE complaints SET status = ? WHERE id = ?";
        $stmt = $conn->prepare($sql_update_status);
        $stmt->bind_param("si", $status, $id);
        $stmt->execute();
        $stmt->close();
    }

    // Mark new complaints as seen when the notification icon is clicked
    if (isset($_GET['mark_seen'])) {
        $update_seen_sql = "UPDATE complaints SET status = 'Seen' WHERE status = 'New'";
        $conn->query($update_seen_sql);
        header("Location: admin_dashboard.php");
    }

    $conn->close();
    ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard | Complaint Management</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
    :root {
        --primary: #4f46e5;
        --primary-light: #6366f1;
        --primary-dark: #4338ca;
        --success: #10b981;
        --success-dark: #059669;
        --warning: #f59e0b;
        --warning-dark: #d97706;
        --danger: #ef4444;
        --danger-dark: #dc2626;
        --info: #3b82f6;
        --info-dark: #2563eb;
        --dark: #1e293b;
        --light: #f8fafc;
        --gray: #94a3b8;
        --gray-dark: #64748b;
        --sidebar-width: 260px;
        --sidebar-collapsed-width: 80px;
        --header-height: 70px;
        --transition-speed: 0.3s;
    }

    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }

    html, body {
        width: 100%;
        height: 100%;
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
        background-color: #f1f5f9;
        color: var(--dark);
        line-height: 1.6;
        overflow: hidden;
    }

    .app-container {
        display: flex;
        min-height: 100vh;
        height: 100%;
    }

    /* Sidebar Styles */
    .sidebar {
        width: var(--sidebar-width);
        background: white;
        box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
        transition: all var(--transition-speed) ease;
        position: fixed;
        height: 100vh;
        z-index: 1000;
        overflow-y: auto;
    }

    .sidebar-collapsed {
        width: var(--sidebar-collapsed-width);
    }

    .sidebar-header {
        padding: 1.5rem 1rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .sidebar-logo {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--primary);
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .sidebar-logo i {
        font-size: 1.5rem;
    }

    .sidebar-menu {
        padding: 1rem 0;
    }

    .sidebar-menu h3 {
        padding: 0.5rem 1rem;
        font-size: 0.75rem;
        text-transform: uppercase;
        letter-spacing: 0.1em;
        color: var(--gray);
        margin-bottom: 0.5rem;
    }

    .sidebar-link {
        display: flex;
        align-items: center;
        padding: 0.75rem 1rem;
        margin: 0 0.5rem;
        color: var(--gray-dark);
        text-decoration: none;
        border-radius: 0.375rem;
        transition: all 0.2s ease;
    }

    .sidebar-link:hover {
        background-color: #f1f5f9;
        color: var(--primary);
    }

    .sidebar-link.active {
        background-color: #e0e7ff;
        color: var(--primary);
        font-weight: 500;
    }

    .sidebar-link i {
        margin-right: 0.75rem;
        width: 24px;
        text-align: center;
    }

    .sidebar-link span {
        white-space: nowrap;
        transition: opacity var(--transition-speed) ease;
    }

    .sidebar-collapsed .sidebar-link span {
        opacity: 0;
        width: 0;
        display: none;
    }

    .sidebar-collapsed .sidebar-menu h3 {
        opacity: 0;
        height: 0;
        padding: 0;
        margin: 0;
        overflow: hidden;
    }

    .sidebar-footer {
        margin-top: auto;
        padding: 1rem;
        border-top: 1px solid #e2e8f0;
    }

    /* Main Content Styles */
    .main-content {
        flex: 1;
        margin-left: var(--sidebar-width);
        transition: margin-left var(--transition-speed) ease;
        height: 100vh;
        display: flex;
        flex-direction: column;
        overflow: hidden;
    }

    .main-content-collapsed {
        margin-left: var(--sidebar-collapsed-width);
    }

    /* Header Styles */
    .header {
        height: var(--header-height);
        background: white;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        padding: 0 2rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
        position: sticky;
        top: 0;
        z-index: 100;
        flex-shrink: 0;
    }

    .header-left {
        display: flex;
        align-items: center;
    }

    .toggle-sidebar {
        background: none;
        border: none;
        color: var(--gray-dark);
        font-size: 1.25rem;
        cursor: pointer;
        margin-right: 1rem;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 40px;
        height: 40px;
        border-radius: 50%;
        transition: all 0.2s ease;
    }

    .toggle-sidebar:hover {
        background-color: #f1f5f9;
        color: var(--primary);
    }

    .header-title {
        font-size: 1.25rem;
        font-weight: 600;
        color: var(--dark);
        transition: opacity var(--transition-speed) ease;
    }

    .main-content-collapsed .header-title {
        opacity: 0;
        width: 0;
    }

    .header-actions {
        display: flex;
        align-items: center;
        gap: 1rem;
    }

    .notification-icon {
        position: relative;
    }

    .notification-badge {
        position: absolute;
        top: -5px;
        right: -5px;
        background-color: var(--danger);
        color: white;
        border-radius: 50%;
        width: 20px;
        height: 20px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.65rem;
        font-weight: 600;
    }

    .user-profile {
        display: flex;
        align-items: center;
        gap: 0.75rem;
    }

    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        background-color: var(--primary-light);
        color: white;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 600;
    }

    .user-name {
        font-weight: 500;
        transition: opacity var(--transition-speed) ease;
    }

    .main-content-collapsed .user-name {
        opacity: 0;
        width: 0;
    }

    /* Content Styles */
    .content-wrapper {
        flex: 1;
        overflow-y: auto;
        padding: 2rem;
    }

    /* Dashboard Cards */
    .dashboard-cards {
        display: grid;
        grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
        gap: 2.5rem;
        margin-bottom: 2rem;
    }

    .card {
        background: white;
        border-radius: 0.5rem;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        padding: 1.5rem;
        transition: transform 0.2s ease;
        position: relative;
        overflow: hidden;
    }

    .card:hover {
        transform: translateY(-5px);
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    }

    .card::before {
        content: '';
        position: absolute;
        top: 0;
        left: 0;
        width: 4px;
        height: 100%;
    }

    .card.complaints::before {
        background-color: var(--info);
    }

    .card.users::before {
        background-color: var(--success);
    }

    .card.completed::before {
        background-color: var(--primary);
    }

    .card-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 1rem;
    }

    .card-title {
        font-size: 0.875rem;
        color: var(--gray-dark);
        font-weight: 500;
        text-transform: uppercase;
        letter-spacing: 0.05em;
    }

    .card-icon {
        width: 40px;
        height: 40px;
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
        color: white;
    }

    .card-icon.new {
        background-color: var(--info);
    }

    .card-icon.in-progress {
        background-color: var(--warning);
    }

    .card-icon.completed {
        background-color: var(--success);
    }

    .card-value {
        font-size: 2rem;
        font-weight: 700;
        color: var(--dark);
        margin-bottom: 0.5rem;
    }

    .card-footer {
        display: flex;
        align-items: center;
        font-size: 0.75rem;
        color: var(--gray);
        margin-top: 1rem;
    }

    .card-footer i {
        margin-right: 0.5rem;
    }

    /* Table Styles */
    .table-container {
        background: white;
        border-radius: 0.5rem;
        box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
        overflow: hidden;
        flex: 1;
        display: flex;
        flex-direction: column;
    }

    .table-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .table-title {
        font-weight: 600;
        color: var(--dark);
    }

    .search-bar {
        position: relative;
    }

    .search-input {
        padding: 0.5rem 1rem 0.5rem 2.5rem;
        border: 1px solid #e2e8f0;
        border-radius: 0.375rem;
        width: 250px;
        transition: all 0.2s ease;
        font-size: 0.875rem;
    }

    .search-input:focus {
        outline: none;
        border-color: var(--primary-light);
        box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
    }

    .search-icon {
        position: absolute;
        left: 1rem;
        top: 50%;
        transform: translateY(-50%);
        color: var(--gray);
    }

    .table-responsive {
        overflow: auto;
        flex: 1;
    }

    .data-table {
        width: 100%;
        border-collapse: collapse;
    }

    .data-table th {
        background-color: #f8fafc;
        padding: 0.75rem 1.5rem;
        text-align: left;
        font-size: 0.75rem;
        font-weight: 600;
        color: var(--gray-dark);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        position: sticky;
        top: 0;
    }

    .data-table td {
        padding: 1rem 1.5rem;
        border-top: 1px solid #e2e8f0;
        font-size: 0.875rem;
    }

    .data-table tr:hover td {
        background-color: #f8fafc;
    }

    .status-badge {
        display: inline-block;
        padding: 0.25rem 0.75rem;
        border-radius: 9999px;
        font-size: 0.75rem;
        font-weight: 500;
    }

    .status-new {
        background-color: #dbeafe;
        color: #1e40af;
    }

    .status-in-progress {
        background-color: #fef3c7;
        color: #92400e;
    }

    .status-seen {
        background-color: #e0e7ff;
        color: #3730a3;
    }

    .status-completed {
        background-color: #dcfce7;
        color: #166534;
    }

    .action-buttons {
        display: flex;
        gap: 0.5rem;
    }

    .btn {
        padding: 0.5rem 0.75rem;
        border: none;
        border-radius: 0.375rem;
        font-size: 0.75rem;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.2s ease;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 0.375rem;
    }

    .btn-sm {
        padding: 0.375rem 0.5rem;
    }

    .btn-primary {
        background-color: var(--primary-light);
        color: white;
    }

    .btn-primary:hover {
        background-color: var(--primary-dark);
    }

    .btn-success {
        background-color: var(--success);
        color: white;
    }

    .btn-success:hover {
        background-color: var(--success-dark);
    }

    .btn-danger {
        background-color: var(--danger);
        color: white;
    }

    .btn-danger:hover {
        background-color: var(--danger-dark);
    }

    .btn-icon {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: 50%;
    }

    .file-link {
        color: var(--primary-light);
        text-decoration: none;
        font-weight: 500;
        display: inline-flex;
        align-items: center;
        gap: 0.375rem;
    }

    .file-link:hover {
        text-decoration: underline;
        color: var(--primary-dark);
    }

    /* Read More Styles */
    .details-content {
        max-height: 3.6em;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        position: relative;
    }

    .details-content.expanded {
        max-height: none;
        -webkit-line-clamp: unset;
    }

    .read-more-btn {
        background: none;
        border: none;
        color: var(--primary-light);
        cursor: pointer;
        font-size: 0.75rem;
        font-weight: 500;
        padding: 0.25rem 0;
        display: inline-flex;
        align-items: center;
    }

    .read-more-btn:hover {
        color: var(--primary-dark);
        text-decoration: underline;
    }

    .read-more-btn i {
        margin-left: 0.25rem;
        font-size: 0.625rem;
        transition: transform 0.2s ease;
    }

    .read-more-btn.expanded i {
        transform: rotate(180deg);
    }

    /* Modal Styles */
    .modal-overlay {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
        background: rgba(0, 0, 0, 0.5);
        display: none;
        justify-content: center;
        align-items: center;
        z-index: 2000;
        padding: 1rem;
    }

    .modal-content {
        background: white;
        border-radius: 0.5rem;
        width: 100%;
        max-width: 600px;
        max-height: 80vh;
        overflow-y: auto;
        box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.1);
        animation: modalFadeIn 0.3s ease;
    }

    @keyframes modalFadeIn {
        from {
            opacity: 0;
            transform: translateY(-20px);
        }
        to {
            opacity: 1;
            transform: translateY(0);
        }
    }

    .modal-header {
        padding: 1rem 1.5rem;
        border-bottom: 1px solid #e2e8f0;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }

    .modal-title {
        font-weight: 600;
        color: var(--dark);
    }

    .close-btn {
        background: none;
        border: none;
        color: var(--gray);
        font-size: 1.25rem;
        cursor: pointer;
        transition: color 0.2s ease;
    }

    .close-btn:hover {
        color: var(--danger);
    }

    .modal-body {
        padding: 1.5rem;
    }

    .complaint-detail {
        margin-bottom: 1.5rem;
    }

    .complaint-detail:last-child {
        margin-bottom: 0;
    }

    .complaint-detail h4 {
        font-size: 1rem;
        color: var(--dark);
        margin-bottom: 0.5rem;
    }

    .complaint-detail p {
        color: var(--gray-dark);
        font-size: 0.875rem;
    }

    .divider {
        height: 1px;
        background-color: #e2e8f0;
        margin: 1rem 0;
    }

    /* Responsive Styles */
    @media (max-width: 1024px) {
        .sidebar {
            transform: translateX(-100%);
            position: fixed;
            z-index: 1000;
        }

        .sidebar.active {
            transform: translateX(0);
        }

        .main-content {
            margin-left: 0;
        }

        .toggle-sidebar {
            display: flex;
        }
    }

    @media (max-width: 768px) {
        .dashboard-cards {
            grid-template-columns: 1fr;
        }

        .search-input {
            width: 180px;
        }

        .header {
            padding: 0 1rem;
        }

        .content-wrapper {
            padding: 1rem;
        }
    }

    @media (max-width: 576px) {
        .header-title {
            display: none;
        }

        .search-input {
            width: 150px;
        }

        .data-table th, 
        .data-table td {
            padding: 0.75rem;
        }

        .action-buttons {
            flex-direction: column;
            gap: 0.25rem;
        }

        .btn {
            width: 100%;
        }
    }
    </style>
</head>
<body>
    <div class="app-container">
        <!-- Sidebar -->
        <div class="sidebar" id="sidebar">
            <div class="sidebar-header">
                <div class="sidebar-logo">
                    <i class="fas fa-shield-alt"></i>
                    <span class="logo-text"></span>
                </div>
            </div>
            <div class="sidebar-menu">
                <h3>Main</h3>
                <a href="dashboard.php" class="sidebar-link">
                    <i class="fas fa-chart-line"></i>
                    <span>Dashboard</span>
                </a>
                <a href="admin_dashboard.php" class="sidebar-link active">
                    <i class="fas fa-tasks"></i>
                    <span>Complaints</span>
                </a>
                <a href="total_registered.php" class="sidebar-link">
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                </a>
                <a href="complaint_history.php" class="sidebar-link">
                    <i class="fas fa-history"></i>
                    <span>History</span>
                </a>
                <a href="admin_help.php" class="sidebar-link">
                    <i class="fas fa-question-circle"></i>
                    <span>Help</span>
                </a>
            </div>
            <div class="sidebar-footer">
                <a href="/final/home.php" class="sidebar-link">
                    <i class="fas fa-sign-out-alt"></i>
                    <span>Logout</span>
                </a>
            </div>
        </div>

        <!-- Main Content -->
        <div class="main-content" id="mainContent">
            <!-- Header -->
            <header class="header">
                <div class="header-left">
                    <button class="toggle-sidebar" id="toggleSidebar">
                        <i class="fas fa-bars"></i>
                    </button>
                    <h1 class="header-title">Complaint Management</h1>
                </div>
                <div class="header-actions">
                    <div class="notification-icon">
                        <button class="btn btn-icon" onclick="showPopup()">
                            <i class="fas fa-bell"></i>
                            <?php if ($new_complaints_count > 0): ?>
                                <span class="notification-badge"><?php echo $new_complaints_count; ?></span>
                            <?php endif; ?>
                        </button>
                    </div>
                    <div class="user-profile">
                        <div class="user-avatar">A</div>
                        <span class="user-name">Admin</span>
                    </div>
                </div>
            </header>

            <!-- Content -->
            <div class="content-wrapper">
                <!-- Dashboard Cards -->
                <div class="dashboard-cards">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">New Complaints</h3>
                            <div class="card-icon new">
                                <i class="fas fa-exclamation"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $new_complaints_count; ?></div>
                        <div class="card-footer">Since last login</div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">In Progress</h3>
                            <div class="card-icon in-progress">
                                <i class="fas fa-sync-alt"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $in_progress_complaints_count; ?></div>
                        <div class="card-footer">Currently being processed</div>
                    </div>
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Total Active</h3>
                            <div class="card-icon completed">
                                <i class="fas fa-clipboard-list"></i>
                            </div>
                        </div>
                        <div class="card-value"><?php echo $new_complaints_count + $in_progress_complaints_count; ?></div>
                        <div class="card-footer">All active complaints</div>
                    </div>
                </div>

                <!-- Complaints Table -->
                <div class="table-container">
                    <div class="table-header">
                        <h3 class="table-title">Active Complaints</h3>
                        <div class="search-bar">
                            <i class="fas fa-search search-icon"></i>
                            <input type="text" class="search-input" placeholder="Search complaints..." onkeyup="filterTable()">
                        </div>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table">
                            <thead>
                                <tr>
                                    <th>Complainant</th>
                                    <th>Title</th>
                                    <th>Location</th>
                                    <th>Details</th>
                                    <th>Attachment</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php while($row = $result->fetch_assoc()): ?>
                                <tr id="row-<?php echo $row['id']; ?>">
                                    <td><?php echo htmlspecialchars($row['full_name']); ?></td>
                                    <td><?php echo htmlspecialchars($row['title_of_complaint']); ?></td>
                                    <td><?php echo htmlspecialchars($row['city']); ?>, <?php echo htmlspecialchars($row['state']); ?></td>
                                    <td>
                                        <div class="details-content">
                                            <?php echo htmlspecialchars($row['details_of_complaint']); ?>
                                        </div>
                                        <button class="read-more-btn" onclick="toggleReadMore(this)">
                                            Read more <i class="fas fa-chevron-down"></i>
                                        </button>
                                    </td>
                                    <td>
                                        <?php if ($row['file']): ?>
                                        <a href="download.php?file=<?php echo urlencode($row['file']); ?>" class="file-link">
                                            <i class="fas fa-paperclip"></i> View
                                        </a>
                                        <?php else: ?>
                                        <span class="text-muted">None</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <span class="status-badge status-<?php echo strtolower(str_replace(' ', '-', $row['status'])); ?>">
                                            <?php echo $row['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <div class="action-buttons">
                                            <button onclick="updateStatus('row-<?php echo $row['id']; ?>', 'In Progress', <?php echo $row['id']; ?>)" 
                                                    class="btn btn-sm btn-primary" title="Mark In Progress">
                                                <i class="fas fa-sync-alt"></i>
                                            </button>
                                            <button onclick="updateStatus('row-<?php echo $row['id']; ?>', 'Completed', <?php echo $row['id']; ?>)" 
                                                    class="btn btn-sm btn-success" title="Mark Completed">
                                                <i class="fas fa-check"></i>
                                            </button>
                                            <button onclick="deleteRow('row-<?php echo $row['id']; ?>', <?php echo $row['id']; ?>)" 
                                                    class="btn btn-sm btn-danger" title="Delete">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                                <?php endwhile; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Notification Modal -->
    <div id="popup" class="modal-overlay">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">New Complaint Notifications</h3>
                <button class="close-btn" onclick="closePopup()">&times;</button>
            </div>
            <div class="modal-body">
                <?php if ($result_new_complaints_details->num_rows > 0): ?>
                    <?php while($row = $result_new_complaints_details->fetch_assoc()): ?>
                        <div class="complaint-detail">
                            <h4><?php echo htmlspecialchars($row['title_of_complaint']); ?></h4>
                            <p><strong>From:</strong> <?php echo htmlspecialchars($row['full_name']); ?></p>
                            <p><strong>Location:</strong> <?php echo htmlspecialchars($row['city']); ?>, <?php echo htmlspecialchars($row['state']); ?></p>
                            <p><strong>Details:</strong> <?php echo htmlspecialchars($row['details_of_complaint']); ?></p>
                            <?php if ($row['file']): ?>
                            <p><strong>Attachment:</strong> <a href="viewfile.php?file=<?php echo urlencode($row['file']); ?>" target="_blank" class="file-link">View File</a></p>
                            <?php endif; ?>
                        </div>
                        <div class="divider"></div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <div class="complaint-detail">
                        <p>No new complaints to display.</p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
    // Toggle sidebar
    const toggleSidebar = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const mainContent = document.getElementById('mainContent');
    let isCollapsed = false;

    // Check if mobile view
    function isMobile() {
        return window.innerWidth <= 1024;
    }

    // Toggle sidebar state
    function toggleSidebarState() {
        if (isMobile()) {
            // Mobile - toggle visibility
            sidebar.classList.toggle('active');
        } else {
            // Desktop - toggle collapsed state
            isCollapsed = !isCollapsed;
            sidebar.classList.toggle('sidebar-collapsed');
            mainContent.classList.toggle('main-content-collapsed');
            
            // Change icon
            const icon = toggleSidebar.querySelector('i');
            icon.className = isCollapsed ? 'fas fa-chevron-right' : 'fas fa-bars';
        }
    }

    // Initialize sidebar
    function initSidebar() {
        if (!isMobile()) {
            sidebar.classList.remove('active');
            sidebar.classList.remove('sidebar-collapsed');
            mainContent.classList.remove('main-content-collapsed');
            toggleSidebar.querySelector('i').className = 'fas fa-bars';
        } else {
            sidebar.classList.remove('sidebar-collapsed');
            mainContent.classList.remove('main-content-collapsed');
            sidebar.classList.remove('active');
        }
    }

    // Event listeners
    toggleSidebar.addEventListener('click', toggleSidebarState);

    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', (event) => {
        if (isMobile() && 
            !sidebar.contains(event.target) && 
            !toggleSidebar.contains(event.target)) {
            sidebar.classList.remove('active');
        }
    });

    // Handle window resize
    window.addEventListener('resize', () => {
        initSidebar();
    });

    // Initialize on load
    document.addEventListener('DOMContentLoaded', initSidebar);

    // Read More functionality
    function toggleReadMore(button) {
        const content = button.previousElementSibling;
        content.classList.toggle('expanded');
        button.classList.toggle('expanded');
        
        if (content.classList.contains('expanded')) {
            button.innerHTML = 'Read less <i class="fas fa-chevron-up"></i>';
        } else {
            button.innerHTML = 'Read more <i class="fas fa-chevron-down"></i>';
        }
    }

    // Filter table rows based on search input
    function filterTable() {
        const input = document.querySelector('.search-input');
        const filter = input.value.toLowerCase();
        const table = document.querySelector('.data-table');
        const rows = table.querySelectorAll('tbody tr');

        rows.forEach(row => {
            const cells = row.querySelectorAll('td');
            let matches = false;
            
            cells.forEach(cell => {
                if (cell.textContent.toLowerCase().indexOf(filter) > -1) {
                    matches = true;
                }
            });
            
            row.style.display = matches ? '' : 'none';
        });
    }

    // Show notification modal
    function showPopup() {
        document.getElementById('popup').style.display = 'flex';
        // Mark notifications as seen
        fetch('admin_dashboard.php?mark_seen=true')
            .then(response => {
                // Update notification badge
                const badge = document.querySelector('.notification-badge');
                if (badge) badge.style.display = 'none';
            });
    }

    // Close notification modal
    function closePopup() {
        document.getElementById('popup').style.display = 'none';
    }

    // Update complaint status
    function updateStatus(rowId, status, complaintId) {
        if (confirm(`Are you sure you want to mark this complaint as ${status}?`)) {
            const form = document.createElement('form');
            form.method = 'post';
            form.style.display = 'none';

            const statusInput = document.createElement('input');
            statusInput.type = 'hidden';
            statusInput.name = 'status';
            statusInput.value = status;
            form.appendChild(statusInput);

            const idInput = document.createElement('input');
            idInput.type = 'hidden';
            idInput.name = 'id';
            idInput.value = complaintId;
            form.appendChild(idInput);

            document.body.appendChild(form);
            form.submit();
        }
    }

    // Delete complaint
    function deleteRow(rowId, deleteId) {
        if (confirm('Are you sure you want to delete this complaint? This action cannot be undone.')) {
            const form = document.createElement('form');
            form.method = 'post';
            form.style.display = 'none';

            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'delete_id';
            input.value = deleteId;
            form.appendChild(input);

            document.body.appendChild(form);
            form.submit();
        }
    }

    // Close modal when clicking outside
    window.addEventListener('click', (event) => {
        const modal = document.getElementById('popup');
        if (event.target === modal) {
            closePopup();
        }
    });
    </script>
</body>
</html>