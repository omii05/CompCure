<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professional Header</title>
    <!-- Font Awesome for Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&family=Montserrat:wght@600;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary: #4361ee;
            --secondary: #3f37c9;
            --light: #f8f9fa;
            --dark: #212529;
        }

        body {
            margin: 0;
            padding: 0;
            font-family: 'Poppins', sans-serif;
            background-color: #f4f9ff;
        }

        header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            padding: 0 5%;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.15);
            position: relative;
            z-index: 1000;
            height: 80px;
        }

        header::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
            opacity: 0.3;
        }

        .logo-container {
            display: flex;
            align-items: center;
            z-index: 1;
        }

        .logo-container img {
            height: 80px;
            margin-right: auto;
            margin-bottom: 15px;
        }

        .logo-container h1 {
            margin: 0;
            font-family: 'Montserrat', sans-serif;
            font-size: 1.8rem;
            font-weight: 700;
            color: white;
            letter-spacing: 0.5px;
            position: relative;
        }

        .logo-container h1::after {
            content: '';
            position: absolute;
            bottom: -5px;
            left: 0;
            width: 100%;
            height: 2px;
            background: linear-gradient(90deg, rgba(255,255,255,0.8) 0%, rgba(255,255,255,0) 100%);
        }

        /* Rest of your existing CSS remains exactly the same */
        nav {
            display: flex;
            align-items: center;
            z-index: 1;
        }

        .nav-links {
            display: flex;
            list-style: none;
            margin: 0;
            padding: 0;
        }

        .nav-links li {
            position: relative;
            margin: 0 10px;
        }

        .nav-links a {
            color: white;
            text-decoration: none;
            font-size: 1rem;
            font-weight: 500;
            padding: 10px 15px;
            border-radius: 6px;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
        }

        .nav-links a i {
            margin-right: 8px;
            font-size: 1.1rem;
            transition: transform 0.3s ease;
        }

        .nav-links a:hover {
            background: rgba(255, 255, 255, 0.15);
            color: var(--light);
        }

        .nav-links a:hover i {
            transform: translateY(-3px);
        }

        .nav-links a.active {
            background: rgba(255, 255, 255, 0.25);
            font-weight: 600;
        }

        .nav-links a.active::after {
            content: '';
            position: absolute;
            bottom: -8px;
            left: 50%;
            transform: translateX(-50%);
            width: 6px;
            height: 6px;
            background-color: var(--accent);
            border-radius: 50%;
        }

        .dropdown {
            position: relative;
            margin-left: 15px;
        }

        .dropdown-toggle {
            cursor: pointer;
            display: flex;
            align-items: center;
            padding: 8px 12px;
            border-radius: 6px;
            transition: all 0.3s ease;
        }

        .dropdown-toggle:hover {
            background: rgba(255, 255, 255, 0.15);
        }

        .dropdown-toggle img {
            height: 24px;
            transition: transform 0.3s ease;
        }

        .dropdown:hover .dropdown-toggle img {
            transform: rotate(90deg);
        }

        .dropdown-content {
            position: absolute;
            right: 0;
            top: 100%;
            background-color: white;
            min-width: 200px;
            border-radius: 8px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.15);
            opacity: 0;
            visibility: hidden;
            transform: translateY(10px);
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            z-index: 1000;
        }

        .dropdown:hover .dropdown-content {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-content a {
            color: var(--dark);
            padding: 12px 20px;
            text-decoration: none;
            display: flex;
            align-items: center;
            transition: all 0.3s ease;
            border-bottom: 1px solid rgba(0, 0, 0, 0.05);
        }

        .dropdown-content a:last-child {
            border-bottom: none;
        }

        .dropdown-content a i {
            margin-right: 10px;
            color: var(--primary);
        }

        .dropdown-content a:hover {
            background-color: var(--primary);
            color: white;
            padding-left: 25px;
        }

        .dropdown-content a:hover i {
            color: white;
        }

        /* Mobile Menu Toggle */
        .menu-toggle {
            display: none;
            cursor: pointer;
            z-index: 1001;
        }

        .menu-toggle i {
            font-size: 1.5rem;
            color: white;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .nav-links {
                position: fixed;
                top: 0;
                right: -100%;
                width: 280px;
                height: 100vh;
                background: linear-gradient(135deg, var(--primary) 0%, var(--secondary) 100%);
                flex-direction: column;
                align-items: flex-start;
                padding: 80px 30px 30px;
                box-shadow: -5px 0 15px rgba(0, 0, 0, 0.1);
                transition: right 0.3s ease;
                z-index: 1000;
            }

            .nav-links.active {
                right: 0;
            }

            .nav-links li {
                margin: 15px 0;
                width: 100%;
            }

            .nav-links a {
                padding: 12px 20px;
                width: 100%;
            }

            .menu-toggle {
                display: block;
                margin-left: 20px;
            }

            .dropdown {
                margin-left: 0;
                width: 100%;
            }

            .dropdown-content {
                position: static;
                display: none;
                width: 100%;
                box-shadow: none;
                opacity: 1;
                visibility: visible;
                transform: none;
                background-color: rgba(255, 255, 255, 0.1);
            }

            .dropdown:hover .dropdown-content {
                display: block;
            }

            .dropdown-content a {
                padding-left: 40px;
                color: white;
                border-bottom-color: rgba(255, 255, 255, 0.1);
            }

            .dropdown-content a i {
                color: white;
            }
        }

        @media (max-width: 576px) {
            .logo-container h1 {
                font-size: 1.5rem;
            }

            header {
                height: 70px;
                padding: 0 20px;
            }
        }
    </style>
</head>
<body>

<header>
    <div class="logo-container">
        <img src="/final/assets/logoc.png" alt="CompCure Logo">
        <h1>CompCure</h1>
    </div>

    <nav>
        <ul class="nav-links">
            <li>
                <a href="home.php" id="homeLink">
                    <i class="fas fa-home"></i>
                    <span>Home</span>
                </a>
            </li>
            <li>
                <a href="about.php" id="aboutLink">
                    <i class="fas fa-info-circle"></i>
                    <span>About</span>
                </a>
            </li>
            <li>
                <a href="contact.php" id="contactLink">
                    <i class="fas fa-envelope"></i>
                    <span>Contact</span>
                </a>
            </li>
            <li>
                <a href="Login.php" id="loginLink">
                    <i class="fas fa-sign-in-alt"></i>
                    <span>Login</span>
                </a>
            </li>
            <li class="dropdown">
                <div class="dropdown-toggle">
                    <img src="/final/assets/setting.png" alt="Settings">
                </div>
                <div class="dropdown-content">
                    <a href="/final/admin/admin.php">
                        <i class="fas fa-user-shield"></i>
                        <span>Admin Login</span>
                    </a>
                    
                    </a>
                    <!-- <a href="#">
                        <i class="fas fa-question-circle"></i>
                        <span>Help</span>
                    </a> -->
                </div>
            </li>
        </ul>

        <div class="menu-toggle">
            <i class="fas fa-bars"></i>
        </div>
    </nav>
</header>

<script>
    // Highlight active link based on current page
    document.addEventListener('DOMContentLoaded', function() {
        const currentPage = window.location.pathname.split('/').pop();
        const navLinks = document.querySelectorAll('.nav-links a');
        
        navLinks.forEach(link => {
            const linkPage = link.getAttribute('href').split('/').pop();
            if (currentPage === linkPage) {
                link.classList.add('active');
            }
        });

        // Mobile menu toggle
        const menuToggle = document.querySelector('.menu-toggle');
        const navLinksContainer = document.querySelector('.nav-links');
        
        menuToggle.addEventListener('click', () => {
            navLinksContainer.classList.toggle('active');
        });
    });
</script>

</body>
</html>