<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "complaint_system";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$success_message = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $contact = $_POST['contact'];
    $password = $_POST['password'];

    // Hash the password before saving it to the database
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (username, email, contact, password) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssss", $username, $email, $contact, $hashed_password);

    if ($stmt->execute()) {
        $success_message = "Registration successful! Redirecting to login...";
        $_SESSION['signup_success'] = true;
        header("Refresh: 3; url=Login.php");
    } else {
        $error_message = "Error: " . $stmt->error;
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Complaint Management System</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');

        :root {
            --primary-blue: #4361ee;
            --dark-blue: #3f37c9;
            --light-blue: #4895ef;
            --white: #ffffff;
            --light-gray: #f8f9fa;
            --medium-gray: #e2e8f0;
            --dark-gray: #64748b;
            --text-color: #212529;
            --success: #4cc9f0;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        html, body {
            height: 100%;
            overflow-x: hidden;
        }

        body {
            font-family: 'Poppins', sans-serif;
            display: flex;
            flex-direction: column;
            background-image: url('/final/assets/bk.png');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
            background-blend-mode: overlay;
            background-color: rgba(255, 255, 255, 0.9);
        }

        /* Header */
        .header {
            background: linear-gradient(135deg, var(--primary-blue) 0%, var(--dark-blue) 100%);
            color: var(--white);
            padding: 30px 0;
            text-align: center;
            width: 100%;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
        }

        .header-content {
            max-width: 1200px;
            width: 90%;
            margin: 0 auto;
        }

        .header h1 {
            font-size: 2.5rem;
            font-weight: 700;
            margin-bottom: 10px;
            text-shadow: 0 2px 4px rgba(0, 0, 0, 0.2);
        }

        .header p {
            font-size: 1.1rem;
            opacity: 0.9;
            max-width: 700px;
            margin: 0 auto;
        }

        /* Main Content */
        .main-content {
            flex: 1;
            padding: 40px 20px;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        /* Signup Container */
        .signup-container {
            background: rgba(255, 255, 255, 0.97);
            border-radius: 16px;
            padding: 40px;
            box-shadow: 0 12px 24px rgba(0, 0, 0, 0.15);
            width: 100%;
            max-width: 500px;
            margin-top: 20px;
            backdrop-filter: blur(8px);
            border: 1px solid rgba(255, 255, 255, 0.3);
            transform: translateY(0);
            animation: fadeInUp 0.6s 0.2s forwards;
            opacity: 0;
            position: relative;
            overflow: hidden;
        }

        @keyframes fadeInUp {
            to { opacity: 1; }
        }

        .signup-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSIxMDAlIiBoZWlnaHQ9IjEwMCUiPjxkZWZzPjxwYXR0ZXJuIGlkPSJwYXR0ZXJuIiB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHBhdHRlcm5Vbml0cz0idXNlclNwYWNlT25Vc2UiIHBhdHRlcm5UcmFuc2Zvcm09InJvdGF0ZSg0NSkiPjxyZWN0IHdpZHRoPSIyMCIgaGVpZ2h0PSIyMCIgZmlsbD0icmdiYSgyNTUsMjU1LDI1NSwwLjA1KSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNwYXR0ZXJuKSIvPjwvc3ZnPg==');
            opacity: 0.05;
        }

        .signup-container h2 {
            color: var(--primary-blue);
            text-align: center;
            margin-bottom: 30px;
            font-size: 2rem;
            font-weight: 700;
            position: relative;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 12px;
        }

        .signup-container h2::after {
            content: '';
            position: absolute;
            bottom: -12px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 4px;
            background: linear-gradient(to right, var(--primary-blue), var(--light-blue));
            border-radius: 2px;
        }

        /* Success Message */
        .success-message {
            background-color: rgba(76, 201, 240, 0.15);
            color: var(--success);
            padding: 16px 20px;
            border-radius: 8px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 12px;
            border-left: 4px solid var(--success);
            animation: fadeIn 0.5s ease;
            backdrop-filter: blur(5px);
        }

        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-10px); }
            to { opacity: 1; transform: translateY(0); }
        }

        /* Form Elements */
        .form-group {
            margin-bottom: 25px;
            position: relative;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 0.5s forwards;
        }

        @keyframes formItemFadeIn {
            to { opacity: 1; transform: translateY(0); }
        }

        .form-group label {
            display: block;
            margin-bottom: 10px;
            font-weight: 500;
            color: var(--text-color);
            font-size: 0.95rem;
        }

        .form-group input {
            width: 100%;
            padding: 15px 20px 15px 50px;
            border: 1px solid var(--medium-gray);
            border-radius: 10px;
            font-family: 'Poppins', sans-serif;
            font-size: 1rem;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            background-color: rgba(248, 249, 250, 0.8);
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        }

        .form-group input:focus {
            border-color: var(--primary-blue);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.1), 0 4px 12px rgba(67, 97, 238, 0.2);
            outline: none;
            background-color: var(--white);
            transform: scale(1.01);
        }

        .form-group i {
            position: absolute;
            left: 18px;
            bottom: 16px;
            color: var(--dark-gray);
            font-size: 1.2rem;
            transition: all 0.3s ease;
        }

        .form-group input:focus + i {
            color: var(--primary-blue);
            transform: scale(1.1);
        }

        /* Signup Button */
        .signup-button {
            background: linear-gradient(135deg, var(--primary-blue), var(--light-blue));
            color: var(--white);
            border: none;
            padding: 16px;
            font-size: 1rem;
            font-weight: 600;
            border-radius: 50px;
            cursor: pointer;
            transition: all 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275);
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 10px;
            box-shadow: 0 4px 15px rgba(67, 97, 238, 0.3);
            width: 100%;
            margin-top: 10px;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .signup-button::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: linear-gradient(135deg, var(--dark-blue), var(--primary-blue));
            opacity: 0;
            transition: all 0.3s ease;
            z-index: -1;
        }

        .signup-button:hover {
            transform: translateY(-3px) scale(1.01);
            box-shadow: 0 8px 20px rgba(67, 97, 238, 0.4);
        }

        .signup-button:hover::before {
            opacity: 1;
        }

        .signup-button:active {
            transform: translateY(0);
        }

        /* Login Link */
        .login-link {
            margin-top: 25px;
            text-align: center;
            font-size: 0.95rem;
        }

        .login-link a {
            color: var(--primary-blue);
            text-decoration: none;
            font-weight: 500;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
            position: relative;
        }

        .login-link a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background: var(--primary-blue);
            transition: width 0.3s ease;
        }

        .login-link a:hover {
            color: var(--dark-blue);
        }

        .login-link a:hover::after {
            width: 100%;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header h1 {
                font-size: 2rem;
            }
            
            .header p {
                font-size: 1rem;
            }
            
            .signup-container {
                padding: 30px;
                margin-top: 15px;
            }
        }

        @media (max-width: 480px) {
            .header {
                padding: 25px 0;
            }
            
            .signup-container {
                padding: 25px 20px;
                border-radius: 12px;
                margin-top: 10px;
            }
            
            .form-group input {
                padding: 14px 20px 14px 45px;
            }
            
            .signup-button {
                padding: 14px;
            }
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="header-content">
            <h1><i class="fas fa-shield-alt"></i> Welcome to CompCure</h1>
            <p>Your voice matters. Register now to submit your complaints easily.</p>
        </div>
    </header>

    <!-- Main Content -->
    <main class="main-content">
        <div class="signup-container">
            <h2><i class="fas fa-user-plus"></i> Create Account</h2>
            
            <?php if (!empty($success_message)): ?>
            <div class="success-message">
                <i class="fas fa-check-circle"></i>
                <span><?php echo $success_message; ?></span>
            </div>
            <?php endif; ?>
            
            <form action="signup.php" method="POST">
                <div class="form-group" style="animation-delay: 0.1s">
                    <label for="username">Username</label>
                    <i class="fas fa-user"></i>
                    <input type="text" id="username" name="username" required placeholder="Enter your username">
                </div>
                <div class="form-group" style="animation-delay: 0.2s">
                    <label for="email">Email Address</label>
                    <i class="fas fa-envelope"></i>
                    <input type="email" id="email" name="email" required placeholder="your@email.com">
                </div>
                <div class="form-group" style="animation-delay: 0.3s">
                    <label for="contact">Contact Number</label>
                    <i class="fas fa-phone-alt"></i>
                    <input type="text" id="contact" name="contact" required placeholder="Enter phone number">
                </div>
                <div class="form-group" style="animation-delay: 0.4s">
                    <label for="password">Password</label>
                    <i class="fas fa-lock"></i>
                    <input type="password" id="password" name="password" required placeholder="••••••••">
                </div>
                <button type="submit" class="signup-button" style="animation-delay: 0.5s">
                    <i class="fas fa-user-plus"></i>
                    <span>Sign Up</span>
                </button>
            </form>
            <div class="login-link">
                <a href="Login.php"><i class="fas fa-sign-in-alt"></i> Already have an account? Log in</a>
            </div>
        </div>
    </main>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Animate form groups sequentially
            const formGroups = document.querySelectorAll('.form-group');
            formGroups.forEach((group, index) => {
                group.style.animationDelay = `${0.1 + (index * 0.1)}s`;
                group.style.animationName = 'formItemFadeIn';
                group.style.animationFillMode = 'forwards';
            });
            
            // Animate signup button
            const signupButton = document.querySelector('.signup-button');
            signupButton.style.animation = 'formItemFadeIn 0.5s 0.5s forwards';
            
            // Prevent form resubmission on refresh
            if (window.history.replaceState) {
                window.history.replaceState(null, null, window.location.href);
            }
        });
    </script>
</body>
</html>